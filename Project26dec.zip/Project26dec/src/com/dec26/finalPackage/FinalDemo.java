package com.dec26.finalPackage;

public class FinalDemo {
final int age;
public FinalDemo() {
	// TODO Auto-generated constructor stub
	age=10;
}
public FinalDemo(int i) {
	this();
	//	age=20;
	
}
public static void main(String[] args) {
//	 FinalDemo f=new FinalDemo()
}
}
