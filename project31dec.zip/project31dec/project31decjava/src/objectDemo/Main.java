package objectDemo;

public class Main {

	public static void main(String[] args) {
		
		Customer customer1=new Customer(9560,"Rohit","Delhi",97000);
		Customer customer2=new Customer(9561,"Rahul","Mumbai",87000);
		Customer customer3=new Customer(9562,"Sachin","Bangalore",77000);
		Customer customer4=new Customer(9563,"Ramesh","Hyderabad",67000);
		
		System.out.println(customer1);
		System.out.println(customer2);
		System.out.println(customer3);
		System.out.println(customer4);
		
		
	}

}
