package com.projecttracker.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(schema = "hr" ,name = "TASKS420")
public class AssignTasks {
      
	  @Id
	  private int userID;
	  @Column
	  private int taskID;
      @Column
	  private String tasks;
	  
	public AssignTasks()
	{
		
	}

	public int getUserID() {
		return userID;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}

	public int getTaskID() {
		return taskID;
	}

	public void setTaskID(int taskID) {
		this.taskID = taskID;
	}

	public String getTasks() {
		return tasks;
	}

	public void setTasks(String tasks) {
		this.tasks = tasks;
	}
	
	
	
      
}
