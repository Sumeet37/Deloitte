
public class Thanks {
public void sayThanks() {
	System.out.println("thanks");
}
}
