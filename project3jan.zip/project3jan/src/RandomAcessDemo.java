import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

public class RandomAcessDemo {

	public static void main(String[] args) throws IOException {
		RandomAccessFile file=new RandomAccessFile("friday.txt", "rw");
		
		file.writeUTF("Today is friyay");
		System.out.println(file.getFilePointer());
		file.seek(0);
		System.out.println(file.getFilePointer());
		
		String str=file.readUTF();
		System.out.println("content is"+str);
		
		//concat
		
		System.out.println(file.getFilePointer());
		file.seek(file.length());
		file.writeUTF("sam ");
		
		file.seek(0);
		
		
		str=file.readLine();//we cant use radUTF here coz it reads only a section of text enclosed between boxes
		System.out.println("content is"+str);
		
		file.close();
		
		
	}
}
