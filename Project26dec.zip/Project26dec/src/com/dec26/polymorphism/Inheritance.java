package com.dec26.polymorphism;

class Animal{

	public void eat() {
		System.out.println("Animal");
	}
	
}
class Dog extends Animal{
	public void eat() {
		System.out.println("dog");
	}
	public void bark() {
		System.out.println("bark");
	}
}

class Cat extends Animal{
	public void eat() {
		System.out.println("cat");
	}
}

public class Inheritance{
	public static void main(String[] args) {
		Animal a=new Dog();
		a.eat();
//		a.bark(); //error
		a=new Cat();
		a.eat();
		
	}
}
