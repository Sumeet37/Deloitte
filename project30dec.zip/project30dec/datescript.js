var amount=parseInt(prompt("enter bill amount",5000));

var today=new Date();
var lastdate=new Date();

lastdate.setFullYear(2019,today.getMonth(),15);


if(today > lastdate){
	
	var day=1000*60*60*24;
	
	var days_ex=(today-lastdate)/day;
	
	
	amount=amount + (days_ex * 50);
	alert("bill due"+amount);
	
	
}else{
	alert("bill to be paid"+amount);
}

