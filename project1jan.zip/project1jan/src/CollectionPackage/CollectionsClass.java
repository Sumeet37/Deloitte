package CollectionPackage;
import java.util.*;

public class CollectionsClass {

		public static void main(String[] args) {
			
		List<String> names=new ArrayList<>();
		names.add("jay");
		names.add("veeru");
		names.add("neha");
		names.add("spring");
		
		
		Collections.sort(names);
		
		System.out.println(names);
		System.out.println(Collections.max(names));
		System.out.println(Collections.min(names));
		Collections.reverse(names);
		System.out.println(names);
		
		
		
	}

}
