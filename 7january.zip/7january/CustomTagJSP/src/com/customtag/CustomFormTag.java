package com.customtag;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

public class CustomFormTag extends TagSupport {

	@Override
	public int doStartTag() throws JspException {
	
		JspWriter out=pageContext.getOut();
		
		try {
			out.println(" <form> <br>");
			out.println("USERNAME :<input type='text' name='username'> ");
			out.println("PASSWORD :<input type='password' name='password'> ");
			out.println("<input type='submit' value='submit' ");
			out.println("</form>");
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return super.doStartTag();
	}
	
	
	
	
}
