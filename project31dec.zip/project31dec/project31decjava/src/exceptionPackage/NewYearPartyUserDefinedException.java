package exceptionPackage;
import java.util.*;

class InvalidAgeException extends Exception{
	public InvalidAgeException() {
	
	}
	
	public InvalidAgeException(String msg) {
		super(msg);

	}
		
}

class NewYearParty {

	int eligibleAge=16;
	Scanner scanner=new Scanner(System.in);
	int age;
	public void enterClub() throws InvalidAgeException {
		System.out.println("enter your age");
		age=scanner.nextInt();
		
		if(age<eligibleAge) {
			throw new InvalidAgeException("under age");
			
		}else {
			System.out.println("welcome");
		}
	}
	
}

public class NewYearPartyUserDefinedException
{
	public static void main(String[] args) {
		NewYearParty obj=new NewYearParty();
		
		try {
			obj.enterClub();
		} catch (InvalidAgeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	
}
