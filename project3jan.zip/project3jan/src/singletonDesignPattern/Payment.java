package singletonDesignPattern;

public class Payment {

	private static Payment payment=new Payment();
	
	private Payment() {
		// TODO Auto-generated constructor stub
		System.out.println("memory allocated");	
	}
	
	public static Payment getPaymentObject() {
		return payment;
	}
	
	public void pay(int amount) {
		System.out.println("payment done INR"+ amount);
	}
	
			
	
}
