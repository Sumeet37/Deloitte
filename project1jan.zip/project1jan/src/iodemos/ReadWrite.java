package iodemos;

import java.io.File;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class ReadWrite {

	public static void main(String[] args) throws IOException {
		Scanner scanner=new Scanner(System.in);
			
		while(true) {
			System.out.println("enterfile name to copy");
			String copyFile=scanner.next();	
			File reader=new File(copyFile);
			
		if(reader.exists()) {
			System.out.println("enterfile name to paste");
			String pasteFile=scanner.next();
			File writer=new File(pasteFile);
			
			FileReader input=new FileReader(reader);
			FileWriter output=new FileWriter(writer);
			int i=0;
			
			while ((i=input.read())!=-1) {
				output.write((char)i);
				
			}
			
			input.close();
			output.close();
			System.out.println("\""+copyFile+"\""+"sucessfully copied to"+"\""+pasteFile+"\"");
			
			break;
		}else {
			System.out.println("\""+copyFile+"\""+"does not exist");
			
		}
		
		}
		
		
		System.out.println("done");
		
	
	}
}
