package CollectionPackage;

public class SetClasses {

}
