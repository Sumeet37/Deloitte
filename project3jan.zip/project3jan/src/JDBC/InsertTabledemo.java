package JDBC;
import java.sql.*;

public class InsertTabledemo {

	public static void main(String[] args) throws SQLException {
	  
		Connection connection=DBConnection.makeConnection();
		Statement statement=connection.createStatement();
		String insertQuery="insert into hr.customer values(1877,'bibhu','bbsr',50000)";
		int rowsAffected=statement.executeUpdate(insertQuery);
		System.out.println("insert sucess "+ rowsAffected);
	}
	
	
	
}
