import java.util.*;

public class CoinChange {

	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		System.out.println("target");
		int target=sc.nextInt();
		System.out.println("array..");
		int arr[]=new int[n];
		for(int i=0;i<n;i++){
			arr[i]=sc.nextInt();
		}
		
		//Brute force recursive solution
		HashMap memo=new HashMap();
		System.out.println(memoized(arr,target,memo));
		
		//tabulation//TBD
		System.out.println(tabulation(arr,target));
		
	}

	public static int tabulation(int[] coins, int amount) {
		int table[]=new int[amount+1];
		Arrays.fill(table, -1);
		table[0]=0;
		
		for (int i = 0; i < table.length; i++) {
			if(table[i]!=-1){
			for(int j=0;j<coins.length;j++){
//				int next=table[i+coins[j]];
//				int current=table[i];
//				if(next==-1 || current+1<next ){
				System.out.println("i="+i+"coin="+coins[j]+(i+coins[j]<table.length));
				if((long)i+coins[j]<(long)table.length){//AIOB
				if(table[i+coins[j]]==-1 || table[i]+1<table[i+coins[j]] ){
					table[i+coins[j]]=table[i]+1;
				}
				}
				
			}
		
			}	
		}
		
		return table[amount];
	}

	public static int memoized(int[] coins,int amount,Map<Integer,Integer> memo) {
		if(memo.containsKey(amount))return memo.get(amount);
		if(amount==0)return 0;
		if(amount<0)return -1;
		int small=-1;
		for (int i = 0; i < coins.length; i++) {
			int remainder=amount-coins[i];
			if(remainder>=0){
			int result=memoized(coins,remainder,memo);
			if(result!=-1){
				result++;
				if(small==-1 || result<small){
					small=result;
				}
			}
			}
			
		}
		memo.put(amount, small);
		return small;
		
	}

}
