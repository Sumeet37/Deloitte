package JDBC;

import java.sql.*;


public class PreparedStatementMain{
public static void main(String[] args) throws SQLException {

	Customer customer=new Customer();
	customer.accept();
	
	Connection connection=DBConnection.makeConnection();
	String query="Insert into hr.customer values(?,?,?,?)";
	PreparedStatement statement=connection.prepareStatement(query);
	
	statement.setInt(1,customer.getCustomerId());
	statement.setString(2,customer.getCustomerName());
	statement.setString(3,customer.getCustomerAddress());
	statement.setInt(4,customer.getBillAmount());
	
	statement.executeUpdate();
	
	System.out.println(customer.getCustomerName()+" , your record saved sucessfully!!");
	
	
}



	
}
