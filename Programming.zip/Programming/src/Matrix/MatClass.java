package Matrix;

public class MatClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SprialPrinting();
	}

	private static void SprialPrinting() {
		
		int mat[][]={
				{1,2,3,4,5},
				{6,7,8,9,10},
				{11,12,13,14,15},
				{16,17,18,19,20},
				{21,22,23,24,25}
		};
		
		/*
		 * 1   2  3  4  5
		 * 6   7  8  9 10
		 * 11 12 13 14 15
		 * 16 17 18 19 20
		 * 21 22 23 24 25
		 * 
		 * 
		 * */
		System.out.println("Printing matrix in spiral form");
		
		int rowSt=0;
		int rowEnd=mat.length-1;
		
		int colSt=0;
		int colEnd=mat[0].length-1;
		
		while(rowSt<=rowEnd){
			//top slice
			for(int c=colSt;c<=colEnd;c++){
				System.out.print(mat[rowSt][c]+" ");
			}
			rowSt++;
			//right slice
			for(int r=rowSt;r<=rowEnd;r++){
				System.out.print(mat[r][colEnd]+" ");
			}
			colEnd--;
			
			//bottom slice
			
			for(int c=colEnd;c>=colSt;c--){
				System.out.print(mat[rowEnd][c]+" ");
			}
			rowEnd--;
			//leftSlice
			for(int r=rowEnd;r>=rowSt;r--){
				System.out.print(mat[r][colSt]+" ");
			}
			colSt++;
			
		}
		
	}

}
