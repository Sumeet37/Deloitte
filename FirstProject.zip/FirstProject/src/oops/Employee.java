package oops;

import java.util.Scanner;


public class Employee {
public int employeeId;
public String employeeName;
public String employeeAddress;
public int salary;
Scanner scanner=new Scanner(System.in);
	public void takeSalary() {
		
		System.out.println("enter id name address salary spearted by space or new line");
 		employeeId=scanner.nextInt();
		employeeName=scanner.next();
		employeeAddress=scanner.next();
		salary=scanner.nextInt();
		
	}
	public void print() {
		System.out.println(employeeAddress);
		System.out.println(employeeId);
		System.out.println(employeeName);
		System.out.println(salary);
	}
}
