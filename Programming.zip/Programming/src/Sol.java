import java.util.HashSet;
import java.util.Set;

public class Sol {
	public static void main(String[] args) {
//        System.out.println(getShortestFragment("ABcabbCa"));
//        System.out.println(getShortestFragment("azABaabza"));
		Sol s=new Sol();
        System.out.println(s.getsmallSubstr("CATattac"));
        System.out.println(s.getsmallSubstr("TacoCat"));
        System.out.println(s.getsmallSubstr("Madam"));
        System.out.println(s.getsmallSubstr("AcZCbaBz"));
        System.out.println(s.getsmallSubstr("azABaabza"));
    }

     int getsmallSubstr(String S){
        for(int k=1;k<=S.length();k++){
            for(int i=0;i<S.length()-k+1;i++){
                Set<Character> lower = new HashSet<>();
                Set<Character> upper = new HashSet<>();
                String tempstr = S.substring(i,i+k);
                char[] temparr = tempstr.toCharArray();
                for(char ch : temparr){
                if(Character.isLowerCase(ch))
                    lower.add(ch);
                else
                    upper.add(ch);
                }
                if(check(lower, upper) && check(upper, lower)){
                    return tempstr.length();
                }
            }            
        }
        return -1;   
    }

     boolean check(Set<Character> first, Set<Character> second){
        Set<Character> l1 = new HashSet<>();
        Set<Character> l2 = new HashSet<>();
        first.forEach((e) -> {
            l1.add(Character.toLowerCase(e));
        });
       second.forEach((e) -> {
            l2.add(Character.toLowerCase(e));
        });
        return l1.containsAll(l2);
    }
}