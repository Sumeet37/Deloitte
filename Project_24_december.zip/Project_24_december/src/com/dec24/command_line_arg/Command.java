package com.dec24.command_line_arg;

public class Command {

		public static void main(String[] args) {
			for(String s:args) {
				System.out.println(s);
			}
		}
}
