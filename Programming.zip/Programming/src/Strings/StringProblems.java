package Strings;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.*;

public class StringProblems {

	static List list=new ArrayList();
	
//	static void fun(String s){
//		System.out.println("String");
//		
//		try{
//			
//		}catch(Exception e){
//			
//		}catch(ArithmeticException e){
//			
//		}
//	}
//	void fun(Object s){
//		System.out.println("Object");
//	}
	
	public static void main(String[] args) {
		
//		fun(null);
		//1.Pallindrome 
		//reverse and check 
		//left right move cursor and check if atleast e chae not matches
		
		//2.Remove a given char from string 
		
		String s="geeks For Geeks";
		int j, count = 0, n = s.length();
	    char []t = s.toCharArray();
		char[]z=new char[s.length()];
		for (int i = j = 0; i < n; i++)
	    {
	        if (t[i] != 'e')
	        z[j++] = t[i];
	        else
	            count++;
	    }
		
		
		//3.all permutation of a String Iterative and recursive way
		
		//Recursive Way
		
		StringBuffer str=new StringBuffer("CDE");
		permutation(str,new StringBuffer(""));
		System.out.println(list);
		
		
		
		//Iterative way 
		//See Copy 
		
		System.out.println("Iterative Solution");
		iterativeSolution();
		
		HashMap<Integer, String> hm=new HashMap<Integer, String>();
		hm.put(1, "helo");
		Iterator i=hm.entrySet().iterator();
		System.out.println("\n hashmap");
		//hashmap
//		while(i.hasNext()){
//			Map.Entry e=(Map.Entry)i.next();
//			System.out.println(e.getKey()+" "+e.getValue());
//		}
		
//		for (Map.Entry e:hm.entrySet()) {
//			System.out.println(e.getKey()+" "+e.getValue());
//		}
		
		hm.forEach((k,v)->{
			System.out.println(k);
			System.out.println(v);
			
		});
		
		
		
		
//		for(Map.Entry<K, V> e:hm){
//			
//		}
		
		
		patternMatching();
		
		
		//Remove consecutive adjacent chars 
		
		removeChar();

		
		//practising
		
		String st="abc";
		
		Set<Character> ss=st.chars().mapToObj(e->(char)e).collect(Collectors.toSet());
		
		
		
		for (int l = 'a'; l <= 'z'; l++) {
			System.out.print((char)l+" ");
		}
		
		
		System.out.println("hello");

		int r[] = { 1, 2, 3, 45, 5 };

		final int max=10;
		Arrays.stream(r).forEach((ele) -> {
			
			System.out.println(max);
		});
		

		String strrr[] = { "a","v"};

		
		Arrays.stream(strrr).forEach((ele) -> {
			
			System.out.println(ele);
		});
		
		// Longest Repeating Character Replacement
		
		characterReplacement();
		
		trimmer();
		
		//1.061899169E7
		//10622489.39
		//10618991.69
		DecimalFormat df = new DecimalFormat("0.00");
		double d=1.061899169E7;
		String srr=new BigDecimal(d).toPlainString();
		
		System.out.print(df.format(d));
		
		char[] ca = new char[26];
		String sst="cat";
		for (char c : sst.toCharArray()) ca[c - 'a']++;
        String keyStr = String.valueOf(ca);
        //System.out.println(keyStr);
		
		

	}//end of main()
	
	private static void trimmer() {
	// TODO Auto-generated method stub
		System.out.println("trimmer");
		
		Set<String> sq=new HashSet<>();
		String s1=new String("42.22");
		String s2=new String("42.22");
		
		DecimalFormat df = new DecimalFormat("0.00");
		double vt = Double.parseDouble("7.08") * Double.parseDouble("7.10");
		System.out.println(vt);
		String vtStr=df.format(vt);
		System.out.println(vtStr);
		
		sq.add(s1);
		sq.add(s2);
		System.out.println(sq);
		
		System.out.println("test");
		
		String s="  aa b  ";
		for(int i=0;i<s.length();i++){
			
			if(s.charAt(i)==' '){
				System.out.println(s.charAt(i)+ "space");
			s=s.replace(" ", "");
			}else{
				System.out.println("tt");
				break;
			}
		}
		System.out.println(s);
	
}

	private static void characterReplacement() {
		System.out.println("characterReplacement");
		String s="AABABBA";
		 int k=1;
		
		 int count[]=new int[26];
		 int maxwindow=Integer.MIN_VALUE;
		 int start=0,end=0;
		 for(; end<s.length();end++){
			 //winlen-maxfreq ele<=k
			 count[s.charAt(end) - 'A']++;
			 //int windowLength=;
			 int maxfreqChar=getMaxfreqChar(count);
			 System.out.println(s.substring(start,end+1) +" "+maxfreqChar);
			 while( (end-start+1)-maxfreqChar > k ){
				 count[s.charAt(start) - 'A']--;
				 start++;
				 maxfreqChar=getMaxfreqChar(count);
			 }
			 
			 maxwindow=Math.max(maxwindow, end-start+1);
			 
			 
		 }
		 
		 System.out.println(maxwindow);
		 
		 
}

	private static int getMaxfreqChar(int[] count) {
		int max=Integer.MIN_VALUE;
		for (int i = 0; i < count.length; i++) {
			max=Math.max(max, count[i]);
		}
		return max;
	}

	//wrong
//	 private static void characterReplacement() {
//	
//		 System.out.println("characterReplacement");
//		 
//		 String s="ABBB";
//		 int k=2;
//		 int count=0;
//		 int max=Integer.MIN_VALUE;
//		 int len=0;
//		 int firstDisSimilarElementIndex=0;
//		 int i,j;
//		 for( i=0,j=0;j<s.length();){
//			 
//			 if(s.charAt(j)!=s.charAt(i)){
//				 count++;
//				 if(count==1){
//					 firstDisSimilarElementIndex=j;
//				 }
//			 }
//			 
//			 if(count>k){
//				 System.out.println(s.substring(i, j) +" " +len);
//				i= firstDisSimilarElementIndex;
//				j=firstDisSimilarElementIndex;
//				count=0;
//				max=Math.max(max, len);
//				len=0;
//			 }else{
//				 len++;
//				 j++;
//			 }
//			 
//			 
//			 
//			 
//		 }
//		 
//		 max=Math.max(max, len);
//		 System.out.println(s.substring(i, j)+" " +len);
//		 System.out.println(max);
//		 
//		 
//}


	private static void removeChar() {
		 
		 System.out.println("Remove Chars");
		 
		 String str="zxxxxzy";
		 
		 String res="";
//		 int dup=1;
		 for (int i = 0; i < str.length(); ) {
			 
			
			 if(res.isEmpty() || str.charAt(i)!=res.charAt(res.length()-1)){
				 
//				 if(dup>1){
//					 res=res.substring(0, res.length()-dup);
//					 dup=1;
//				 }
//				 
				 res=res+str.charAt(i);
				 i++;
				 
			 }else{
//				 dup++;
//				 res=res+str.charAt(i);
				 
				 while(i<str.length() && str.charAt(i)==res.charAt(res.length()-1) ){
					
					 i++;
				 }
				 res=res.substring(0, res.length()-1);
				 
				 
			 }
			 
		}
		 
		 System.out.println(res);
	
}


	static void patternMatching() {
	String str="abde1brd";
	System.out.println(str.matches("(.*)\\d+(.*)"));
	
	String x="b*d";
	String rep=x.replace("*", "(.)");
	String regex="(.*)"+rep+"(.*)";
	
	
	System.out.println("regex");
	System.out.println(str.matches("(.*)\\d+(.*)"));
	System.out.println(regex);
//	System.out.println(Pattern.matches(regex, str));
//	regex="bcd";
	Pattern pattern = Pattern.compile(regex);
    Matcher matcher = pattern.matcher(str);
    // Check all occurrences
    while (matcher.find()) {
        System.out.print("Start index: " + matcher.start());
        System.out.print(" End index: " + matcher.end());
        System.out.println(" Found: " + matcher.group());
    }
    
    
	
}


	public static void  permutation(StringBuffer targetStr,StringBuffer ans) {
		
		//WE CAN USE STRING ALL THE WAY AND USE SUBSTRING METHOD
		
		if(targetStr.length()==0){
			//base
//			System.out.println(targetStr);
//			l.add(targetStr);
			list.add(ans);
			return ;
		}
		for(int i=0;i<targetStr.length();i++){
			char edge=targetStr.charAt(i);
			
			StringBuffer temp=new StringBuffer(targetStr);
			StringBuffer target=temp.deleteCharAt(i);
//			StringBuffer target = targetStr.substring(0, i).append(targetStr.substring(i + 1));
			
//			StringBuffer newAnswer=ans.append(edge);
//			System.out.println("target is " +target+ " answer is "+ans.toString()+edge);
			permutation(target,new StringBuffer(ans.toString()+edge));
//			result.append(edge);
//			l.add(result);
			
		}
		
		
		return ;
		
	}
	
	 public static void iterativeSolution() {
			// TODO Auto-generated method stub
				String inp="abcd";
				
				int len=inp.length();
				int fact=24; //int fact=factorial(len);
				
				int q;
				StringBuffer buff;
				for (int i = 0; i < fact; i++) {
					
					q=i;
					buff=new StringBuffer(inp);
					for (int j = len; j > 0; j--) {
						int rem=q%j;
						q=q/j;
						System.out.print(buff.charAt(rem));
						buff.deleteCharAt(rem);
						
					}
					System.out.print(" , ");
				}
			
		}

	
}
