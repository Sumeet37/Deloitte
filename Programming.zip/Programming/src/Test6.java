import java.util.*;
import java.util.Stack;

//313 start meesho q 3 // c++
public class Test6 {

	static int solve(String s, int n, int l, int r, int i){
	    if(l<0 || l>n)
	        return 0;
	    if(l==r){
	        if(i<s.length()){
	            if(s.charAt(i)=='l')
	                return 1+solve(s,n,l-1,r,i+1);
	            else
	                return 1+solve(s,n,l+1,r,i+1);
	        }
	    }
	    if(i==s.length())
	        return 0;
	    int ans=0;
	    //exclude
	    ans+=solve(s,n,l,r,i+1);
	    //include
	    if(s.charAt(i)=='l')
	        ans+=solve(s,n,l-1,r,i+1);
	    else
	        ans+=solve(s,n,l+1,r,i+1);
	    return ans;
	}
	
	
	static int segment(int x, int[] space){
	    int n = space.length;
	    if(n==1)
	        return space[0];

	    int count = 0;
	    int currMin = Integer.MAX_VALUE;
	    int globMax = -1;
	    for(int i=0; i<n; i++){
	        if(count<x){
	            currMin = Math.min(currMin, space[i]);
	        }else{
	            globMax = Math.max(globMax, currMin);
	            if(space[i-count]==currMin){
	                currMin = space[i-count+1];
	                int j = i-count+1;
	                while(j<=i){
	                    currMin = Math.min(currMin, space[j]);
	                    j++;
	                }
	            }else{
	                currMin = Math.min(currMin, space[i]);
	            }
	        }
	    }
	    globMax = globMax == -1?currMin:globMax;
	    return globMax;
	}
	
	public static int FindMax(int[] space, int x)
	{
	    int chunkNum = 1;
	    Stack<Integer> s = new Stack<Integer>();
	    s.push(0);

	    for (int i = 1; i < space.length; i++)
	    {
	        // first chunk
	        if (i < x)
	        {
	            if (space[i] < space[s.peek()])
	            {
	                s.pop();
	                s.push(i);
	            }
	        }
	        // other chunks
	        else
	        {
	            // if found minimum is member of current chunk we just need to compare current number with it
	            int peek = s.peek();
	            if (peek >= chunkNum)
	            {
	                s.push(space[i] < space[peek] ? i: peek);
	            }
	            // we have to loop through current chunk to find minimum number
	            else
	            {                
	                s.push(i);
	                
	                int j = chunkNum;
	                int count = 0;
	                while (count++ < x)
	                {
	                    if (space[j] < space[s.peek()])
	                    {
	                        s.pop();
	                        s.push(j);
	                    }
	                    j++;
	                }
	            }
	            // we are ready to go to next chunk
	            chunkNum++;
	        }
	    }
	    int maz=Integer.MIN_VALUE;
	    for(int c:s){
	    	maz=Math.max(maz, space[c]);
	    }
	    
//	    return s.Select(c => space[c]).Max();
	    return maz;
	}
	
	static int count=0;
	
    public static boolean wordBreak(Set<String> dictionary,String word)
    {
        int size = word.length();
         
        // base case
        if (size == 0)
        return true;
//         boolean res=false;
        //else check for all words
        for (int i = 1; i <= size; i++)
        {
            // Now we will first divide the word into two parts ,
            // the prefix will have a length of i and check if it is
            // present in dictionary ,if yes then we will check for
            // suffix of length size-i recursively. if both prefix and
            // suffix are present the word is found in dictionary.
 
            if (dictionary.contains(word.substring(0,i)) &&
                    wordBreak(dictionary,word.substring(i,size)))
//            	count++;
            return true;
        }
         
        // if all cases failed then return false
        return false;
    }

    public static boolean wordBreak2(Set<String> dictionary,String word)
    {
        int size = word.length();
         
        // base case
        if (size == 0)
        return true;
         boolean res=false;
        //else check for all words
        for (int i = 1; i <= size; i++)
        {
            // Now we will first divide the word into two parts ,
            // the prefix will have a length of i and check if it is
            // present in dictionary ,if yes then we will check for
            // suffix of length size-i recursively. if both prefix and
            // suffix are present the word is found in dictionary.
 
            if (dictionary.contains(word.substring(0,i)) &&
                    wordBreak(dictionary,word.substring(i,size))){
            	count++;
            System.out.println(word.substring(0,i)+ " " +word.substring(i,size) +count+" count");
            }
            res= true;
        }
         
        // if all cases failed then return false
        return res;
    }

    
    
    	
	public static void main(String[] args) {
		
		
		
		
		
		
		
		System.out.println(Math.abs(6-10));
		
		// TODO Auto-generated method stub
//		String s="rrlrlr";
//		int n=6;
//		int l=1;
//		int r=2;
//		int ans=solve(s,n,l,r,0);
//		System.out.println(ans);
		int arr[]={1,2,3,1,2};
//		int arr[]={2,5,4,6,8};
		int x=1;
//		System.out.println(segment(x,arr));
		System.out.println(FindMax(arr,x));
		
		//Output- 2 (cat sand dog & cats and dog)
		String temp_dictionary[] = {"mobile","samsung","sam","sung",
                "man","mango","icecream","and",
                "go","i","like","ice","cream","cat","sand","cat","dog","cats",};
		Set<String> dictionary = new HashSet<>();
		for (String temp :temp_dictionary)
        {
            dictionary.add(temp);
        }
		
		System.out.println(wordBreak2(dictionary,"catsanddog"));
		System.out.println("catsanddog"+count);
		
		
//		fun();
		char[] data=new char[26];
		data[0]++;
		System.out.println("VAlueOF");
		System.out.println(String.valueOf(data));
		
		String st="ba";
		char[] d1=st.toCharArray();
		Arrays.sort(d1);
		System.out.println("VAlueOFD1");
		System.out.println(String.valueOf(d1));
		
		//
		
		String st1="bad";
		char[] d11=st.toCharArray();
		
		
		System.out.println("slash");
		System.out.println(String.valueOf(d11));
		
		
		
	}


//	private static void fun() {
//		String book_str="01001"
//		res = 0
//			    count_map = defaultdict(int)
//			    for page in book_str:
//			        count_map[page] += 1
//			    
//			    zeros = count_map['0']
//			    ones = count_map['1']
//			    
//			    # try the case 101
//			    starting_ones = 0
//			    ending_ones = ones
//			    for page in book_str:
//			        if page == '0':
//			            res += starting_ones * ending_ones
//			        else:
//			            ending_ones -= 1
//			            starting_ones += 1
//			    
//			    # try the case 010
//			    starting_zeros = 0
//			    ending_zeros = zeros
//			    for page in book_str:
//			        if page == '1':
//			            res += starting_zeros * ending_zeros
//			        else:
//			            ending_zeros -= 1
//			            starting_zeros += 1
//
//			    return res
//		
//	}

}
