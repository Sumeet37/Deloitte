package com.shopping.deloitte.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class AuthenticateServlet
 */
public class AuthenticateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AuthenticateServlet() {
        super();
       
    }

	
	public void init(ServletConfig config) throws ServletException {
		
		
	}

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");

		//jdbc code herer
		
		//
		
//		if (username.startsWith("t")) {
//			
//			RequestDispatcher dispatcher=request.getRequestDispatcher("Item.html");
//			dispatcher.forward(request, response);
//			
//		}else {
//			
//			response.sendRedirect("LoginForm.html");
//			
//		}
//		
//		
		
		//sessions
		HttpSession session=request.getSession();
		session.setAttribute("CurrentBuyer", username);
		
		
		Cookie allCookies[]=request.getCookies();
		
		boolean alreadyVisited=false;
		
		if(allCookies!=null) {
			for(Cookie c: allCookies) {
				if(c.getName().equals(username)) {
					alreadyVisited=true;
					break;
				}
			}
		}
		out.println("<h1>Successfully authenticated");
		
		if(!alreadyVisited) {
			out.println("<h1>Welcome , you are the first visitor, : ");
			Cookie cookie=new Cookie(username, username);
			response.addCookie(cookie);
			System.out.println("Cookie set");
		}
		else {
			out.println("<h1>Welcome anyway, you have already visited");
		}
		
		out.println("<h2><form action='AdminServlet'>");
		out.println("<h2>wife name : <input type='text' name='wifename'>");
		out.println("<h2><input type='hidden' name='username' value="+username+">");
		out.println("<input type='submit' value='submit'>");
		out.println("<h2></form>");
		
		
		
		
//		if(username.equalsIgnoreCase("guest")) {
//			RequestDispatcher dispatcher=request.getRequestDispatcher("GuestServlet");
//			dispatcher.include(request, response);
//			
//		}else if(username.equalsIgnoreCase("admin")) {
//			RequestDispatcher dispatcher=request.getRequestDispatcher("AdminServlet");
//			dispatcher.include(request, response);
//		}else {
//			RequestDispatcher dispatcher=request.getRequestDispatcher("OtherServlet");
//			dispatcher.forward(request, response);
//		}
		
		
		
		
		
		
	
	}//services

}





