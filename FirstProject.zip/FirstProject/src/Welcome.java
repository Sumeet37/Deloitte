

public class Welcome {

	public static void main(String[] args) {
		System.out.println("welcome");
		Bye b=new Bye();
		b.sayBye();
		Thanks t=new Thanks();
		t.sayThanks();
		Hello h=new Hello();
		h.sayHello();
		Adios a=new Adios();
		a.sayAdios();
		
		finance.Salary s=new finance.Salary();
		int result=s.calculateSalary(2000,1200);
		System.out.println(result);		
		
	}
}
