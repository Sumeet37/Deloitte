package CollectionPackage;

import java.util.*;

public class ArraylistDemo1 {

public static void main(String[] args) {
	List names=new ArrayList();
	
	names.add("Zedd");
	names.add("halsey");
	names.add("lewis");
	names.add("dean");
	names.add("dean");
	
	System.out.println(names);

	names.add(3, "calcum");
	System.out.println(names);
	
	names.remove("dean");
	System.out.println(names);
	
	System.out.println(names.isEmpty());
	System.out.println(names.contains("dean"));
	
	
	
}	
	
}
