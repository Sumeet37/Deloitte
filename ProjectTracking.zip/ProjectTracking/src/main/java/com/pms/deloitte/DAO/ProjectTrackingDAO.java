package com.pms.deloitte.DAO;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.pms.deloitte.model.Employee;


@Repository
public interface ProjectTrackingDAO extends CrudRepository<Employee, Integer>{
	
	
}
