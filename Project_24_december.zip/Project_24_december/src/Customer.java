
public class Customer {
	private int  customerId;
	private String customername;
	private String customerAddress;
	private int billAmount=1000;
	
	public Customer() {
	// TODO Auto-generated method stub
	customerId=500;
	customername="NA";
	customerAddress="NA";
	billAmount=1000;
	System.out.println("customer constructor");
	}
	public Customer(int customerId, String customername,String customerAddress,int billAmount) {
		this.customerId=customerId;
		this.customername=customername;
		this.customerAddress=customerAddress;
		this.billAmount=billAmount;
		System.out.println("parametr constructor ");
	}
	public void display() {
		System.out.println(customerId);
		System.out.println(customername);
		System.out.println(customerAddress);
		System.out.println(billAmount);
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomername() {
		return customername;
	}
	public void setCustomername(String customername) {
		this.customername = customername;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public int getBillAmount() {
		return billAmount;
	}
	public void setBillAmount(int billAmount) {
		this.billAmount = billAmount;
	}
	public static void main(String[] args) {
		Customer c=new Customer();
		Customer c1=new Customer(12,"sam","bang",1000);
		c.setCustomerId(20);
		c.setCustomername("sam");
		c.setCustomerAddress("ctc");
		c.setBillAmount(6000);
		c.display();
		c1.display();
		
	}
}
