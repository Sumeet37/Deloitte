package com.pms.deloitte.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pms.deloitte.DAO.ProjectTrackingDAO;

@Service
public class ProjectTrackingServiceImpl implements ProjectTrackingService {

	@Autowired
	ProjectTrackingDAO projectTrackingDAO;
	
	
	
	
}
