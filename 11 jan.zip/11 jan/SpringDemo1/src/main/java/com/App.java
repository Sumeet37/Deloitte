package com;


public class App 
{
    public static void main( String[] args )
    {
        Customer customer=new Customer();
        customer.setCustomerName("sam");
        System.out.println(customer);
    }
}
