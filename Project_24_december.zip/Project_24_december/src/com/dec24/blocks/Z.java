package com.dec24.blocks;

public class Z {
W w=new W();
	{
		System.out.println("instance block");
	}
	static {
		System.out.println("static block");
	}
	public Z() {
		System.out.println("In Z constructor");
	}
	public static void main(String[] args) {
		System.out.println("in main");
		new Z();
		
	}
}
