package com.dec26.innerclass;

class ChangePassword{
	String password="pass@1";
	/////////////////////////////
	class EncryptPassword{
		int passlevel=2;
		///////////////////////
		public void doEncrypt() {
			System.out.println("the password is "+password);//outer class variables accesed
			
		}
	}
}

public class DemoInnerclass {
	public static void main(String[] args) {
		ChangePassword cp=new ChangePassword();
		ChangePassword.EncryptPassword obj=cp.new EncryptPassword();
		obj.doEncrypt();	
	}
	
}
