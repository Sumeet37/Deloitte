import java.util.Scanner;

abstract class Arithmetic{
	int num1,num2;
	public Arithmetic() {
		// TODO Auto-generated constructor stub
	}
//	public Arithmetic(int num1,int num2) {
//		this.num1=num1;
//		this.num2=num2;
//	}
	void read() {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter numbers");
		int num1=sc.nextInt();
		int num2=sc.nextInt();
		int result=calculate(num1,num2);
		display(result);
	}
	void display(int result) {
		System.out.println(result);
	}
	 abstract int calculate(int a,int b);
	
	
}
 class Add extends Arithmetic {
	@Override
	 int calculate(int a, int b) {
		return a+b;
	}

}
 class Sub extends Arithmetic {
		@Override
		 int calculate(int a, int b) {
			return a-b;
		}

	}

 class Mul extends Arithmetic {
		@Override
		 int calculate(int a, int b) {
			return a*b;
		}

	}
 class Div extends Arithmetic {
		@Override
		 int calculate(int a, int b) {
			return a/b;
		}

	}


 

public class Calculator {

	public static void main(String[] args) {
		
		Arithmetic arr[]= {new Add(), new Sub(), new Mul(), new Div()};
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter your choice:\n1. Add\n2. Sub\n3. Multiply\n4. Divide");
		int choice=sc.nextInt();
		
		
		arr[choice-1].read();
		
		
//		
	}
}




