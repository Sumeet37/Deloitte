package product;

import objectDemo.Customer;

public class Main {

	public static void main(String[] args) {
		
		Product product1=new Product(1, "Bat" , 5, 500);
		Product product2=new Product(2, "Ball", 5, 400);
		Product product3=new Product(3, "Wickets", 5, 300);
		Product product4=new Product(4, "Helmet", 5, 200);
		
		System.out.println(product1);
		System.out.println(product2);
		System.out.println(product3);
		System.out.println(product4);

	}

}
