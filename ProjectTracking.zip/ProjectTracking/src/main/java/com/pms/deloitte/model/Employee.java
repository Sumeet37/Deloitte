package com.pms.deloitte.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(schema="hr",name="employee101")
public class Employee implements Serializable{

	@Id
	private int employeeId;
	@Column
	private String password;
	@Column
	private boolean adminStatus;
	@Column
	private Set<String> taskToDo;
	@Column
	private Set<String> taskDone;
	
	
	
	public Employee() {
		// TODO Auto-generated constructor stub
	}

	public Employee(int employeeId, String password, boolean adminStatus, Set<String> taskToDo, Set<String> taskDone) {
		super();
		this.employeeId = employeeId;
		this.password = password;
		this.adminStatus = adminStatus;
		this.taskToDo = taskToDo;
		this.taskDone = taskDone;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isAdminStatus() {
		return adminStatus;
	}

	public void setAdminStatus(boolean adminStatus) {
		this.adminStatus = adminStatus;
	}

	public Set<String> getTaskToDo() {
		return taskToDo;
	}

	public void setTaskToDo(Set<String> taskToDo) {
		this.taskToDo = taskToDo;
	}

	public Set<String> getTaskDone() {
		return taskDone;
	}

	public void setTaskDone(Set<String> taskDone) {
		this.taskDone = taskDone;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (adminStatus ? 1231 : 1237);
		result = prime * result + employeeId;
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		result = prime * result + ((taskDone == null) ? 0 : taskDone.hashCode());
		result = prime * result + ((taskToDo == null) ? 0 : taskToDo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (adminStatus != other.adminStatus)
			return false;
		if (employeeId != other.employeeId)
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		if (taskDone == null) {
			if (other.taskDone != null)
				return false;
		} else if (!taskDone.equals(other.taskDone))
			return false;
		if (taskToDo == null) {
			if (other.taskToDo != null)
				return false;
		} else if (!taskToDo.equals(other.taskToDo))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", password=" + password + ", adminStatus=" + adminStatus
				+ ", taskToDo=" + taskToDo + ", taskDone=" + taskDone + "]";
	}
	
	
	
	
}










