package com.pms.deloitte.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.pms.deloitte.model.Product;

@Controller
public class ProductController {

	@RequestMapping("/product")
	public ModelAndView product(){

		ModelAndView view=new ModelAndView("product");
		view.addObject("command", new Product());
		return view;
		
		
	}
	
	
	@RequestMapping("/saveProduct")
	public ModelAndView saveProduct(Product product){
		//dao layer code here
		ModelAndView view=new ModelAndView("product");
		System.out.println(product);
		view.addObject("command", new Product());
		
		return view;
		
		
	}
	
	
	
}
