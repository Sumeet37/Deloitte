package com.dec26.innerclass;

interface ChangePasswordInterface{
	void doChange();
}
public class DemoAnonymousClass {

	public static void main(String[] args) {
		ChangePasswordInterface cp=new ChangePasswordInterface() {
			
			@Override
			public void doChange() {
				System.out.println("inside annonymous inner class");
				
			}
		};
		
		cp.doChange();
		
 	}
}
