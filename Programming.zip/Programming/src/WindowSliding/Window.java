package WindowSliding;

import java.util.HashMap;
import java.util.HashSet;

public class Window {

	
	
	public static void main(String[] args) {
		
		SmallestSubArrayWithGivenSum();
		
		//Longest Substring With At Most K Unique Characters
		
		LongestSubWithATMOSTKCHARS();
		
		betterLongestSubWithATMOSTKCHARS();
		
		//Longest Substring With exactly  K Unique Characters 
		
		LongestSubWithEXACTLYKChars();
		
		
		//Length of the longest substring without repeating characters
		
		lengthOfLongestSubstring();
		
		
		//Smallest window that contains all characters of string itself
		
		smallestWindowContainingAllCharsOfStringItself();
		
		
	}

	private static void smallestWindowContainingAllCharsOfStringItself() {

		System.out.println("Smallest window that contains all characters of string itself");

		String s = "aaab";

		HashMap<Character, Integer> hm = new HashMap<>();

		for (int i = 0; i < s.length(); i++) {
			hm.put(s.charAt(i), hm.getOrDefault(s.charAt(i), 0) + 1);
		}

		int k = hm.size();
		hm = new HashMap<>();

		int smallest = Integer.MAX_VALUE, si = 0, sj = 0;

		int i = 0, j = 0;

		for (; j < s.length(); j++) {
			hm.put(s.charAt(j), hm.getOrDefault(s.charAt(j), 0) + 1);

			while (hm.size() == k) {

				if (j - i + 1 < smallest) {
					smallest = j - i + 1;
					si = i;
					sj = j;
				}

				if (hm.get(s.charAt(i)) == 1) {
					hm.remove(s.charAt(i));
				} else {
					hm.put(s.charAt(i), hm.get(s.charAt(i)) - 1);
				}
				i++;
			}
			
		}
		
		System.out.println(s.substring(si, sj+1));
	}

	private static void lengthOfLongestSubstring() {
		System.out.println(" Longest Substring Without Repeating Characters ");
		String s="abcabcbb";

		char a[]=s.toCharArray();
		HashSet<Character> hs=new HashSet<Character>();
		int maxLen=Integer.MIN_VALUE;
		
//		for (int i = 0,j=0; j<a.length ;j++ ) {
//			System.out.println(hs);
//			if(hs.contains(a[j])){
//				
//				while(hs.contains(a[j]) && i<=j){
//					hs.remove(a[i]);
//					i++;
//				}
//				hs.add(a[j]);
//				
//			}else{
//				hs.add(a[j]);
//			}
//			//System.out.println(j-i+1 + " "+maxLen);
////			System.out.println(s.substring(i, j+1));
//			maxLen=Math.max(maxLen, j-i+1);
//		}
		
		for (int i = 0, j = 0; j < a.length; j++) {
			System.out.println(hs);

			while (hs.contains(a[j]) && i <= j) {
				hs.remove(a[i]);
				i++;
			}
			hs.add(a[j]);

			// System.out.println(j-i+1 + " "+maxLen);
			// System.out.println(s.substring(i, j+1));
			maxLen = Math.max(maxLen, j - i + 1);
		}
		
		 if(maxLen==Integer.MIN_VALUE){
			 System.out.println("0");
	        }
		System.out.println(maxLen);
		
	}

	private static void LongestSubWithEXACTLYKChars() {
		
		System.out.println(" EXACTLY K CHARS");
		String str="aaaa";
		int k=2;
		
		char a[]=str.toCharArray();
		HashMap<Character,Integer> hm=new HashMap<Character,Integer>();
		int maxLength=Integer.MIN_VALUE;
		
		for (int i = 0,j=0; j < a.length; j++) {
		
			if(hm.containsKey(a[j])){
				hm.put(a[j], hm.get(a[j])+1);
			}else{
				hm.put(a[j], 1);
			}
			
			while(hm.size()>k){
				if(hm.get(a[i])==1){
					hm.remove(a[i]);
				}else{
					hm.put(a[i], hm.get(a[i])-1);
				}
				i++;
			}
			
			if(hm.size()==k){
				maxLength=Math.max(maxLength, j-i+1);
			}
			
			
		}
		
		if(maxLength==Integer.MIN_VALUE){
			System.out.println("-1");
		}else{
		System.out.println(maxLength);
		}
		
	}

	private static void betterLongestSubWithATMOSTKCHARS() {
		
		System.out.println("better code LongestSubWithATMOSTKCHARS ");
		String str="vmhgfxjfjgmhdjgdydgjmhcgfcfgcgjvhhdxdasyjtf";
		int k=4;
		char a[]=str.toCharArray();
		HashMap<Character,Integer> hm=new HashMap<Character,Integer>();
		int maxLength=Integer.MIN_VALUE;
		
		for (int i = 0,j=0; j < a.length; j++) {
		
			if(hm.containsKey(a[j])){
				hm.put(a[j], hm.get(a[j])+1);
			}else{
				hm.put(a[j], 1);
			}
			
			while(hm.size()>k){
				if(hm.get(a[i])==1){
					hm.remove(a[i]);
				}else{
					hm.put(a[i], hm.get(a[i])-1);
				}
				i++;
			}
			maxLength=Math.max(maxLength, j-i+1);
			
		}
		System.out.println(maxLength);
		
		
		
	}

	private static void LongestSubWithATMOSTKCHARS() {
		System.out.println("LongestSubWithATMOSTKCHARS");
		
		String str="vmhgfxjfjgmhdjgdydgjmhcgfcfgcgjvhhdxdasyjtf";
		int k=4;
		
		char a[]=str.toCharArray();
		HashMap<Character,Integer> hm=new HashMap<Character,Integer>();
		int currLength=0;
		int maxLength=Integer.MIN_VALUE;
		for (int i = 0,j=0; i<=j && j<a.length; ) {
			
			if(hm.size()==k && !hm.containsKey(a[j])){
				hm.put(a[j], 1);
				
				while(hm.size()>k){
					if(hm.get(a[i])==1){
						hm.remove(a[i]);
					}else{
						hm.put(a[i], hm.get(a[i])-1);
					}
					i++;
					currLength--;
				}
				
			}else{
				
				if(hm.containsKey(a[j])){
					hm.put(a[j], hm.get(a[j])+1);
				}else{
					hm.put(a[j], 1);
				}
				currLength++;
				maxLength=Math.max(currLength, maxLength);
				j++;
				
			}
			
			
		}
		
		System.out.println(maxLength);
		
	}

	private static void SmallestSubArrayWithGivenSum() {
		
		int arr[]={2,3,1,2,4,3};//{4,2,2,7,8,1,2,8,10};
		int sum=7;//8;
		
		int currentSum=0;
		int minSize=Integer.MAX_VALUE;
		
		
		for (int i = 0,j=0; i<=j && j<arr.length; ) {
			
			currentSum=currentSum+arr[j];
			
			while(currentSum>=sum && i<=j){
				System.out.println(i + " "+j );
				minSize=Math.min(minSize, j-i+1);
				currentSum=currentSum-arr[i];
				i++;
			}
			
			j++;
		}
		
		System.out.println("Minimum subarray is of length = "+minSize);
		
	}
}
