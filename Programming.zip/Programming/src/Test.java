////import java.time.LocalDate;
////import java.time.LocalDateTime;
////import java.time.LocalTime;
////import java.time.format.DateTimeFormatter;
////import java.util.*;
////
////public class Test {
////
////	public static void main(String[] args) {
////		// TODO Auto-generated method stub
////
//////		System.out.println(findMinDaysUsingMath(4));
//////		System.out.println(findMinDaysUsingMath(99));
////		
////		for(int i =2; i<1000;i++){
////			if(findMinDaysUsingMath(i)!=findMinDaysUsingProgram(i)){
////				System.out.println(i);
////			}
////		}
////		
////		//Folder Score(asked at McAfee)
////		
////		HashMap<Character,List<Character>> hm=new HashMap<>();
////
////		List<Character> l=new ArrayList<>();
////		l.add('B');
////		l.add('C');
////		hm.put('A', new ArrayList<>(l));
////		l.clear();
////		l.add('D');
////		l.add('E');
////		hm.put('B', new ArrayList<>(l));
////		hm.put('C', new ArrayList<>());
////		hm.put('D', new ArrayList<>());
////		l.clear();
////		l.add('F');
////		hm.put('E', new ArrayList<>(l));
////		hm.put('F', new ArrayList<>());
////		
////		System.out.println(hm);
////		
////		System.out.println("score");
////		Character folder='D';
////		System.out.println(score(hm,folder,new HashMap<>()));
////		
////		
////		
////		//TimeStamp
////		String str="2022-02-08";
////		
////		LocalDateTime startdateTime = LocalDate.parse(str).atStartOfDay();
////		LocalDateTime end = LocalDate.parse(str).atTime(LocalTime.MAX);
////		DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS", Locale.ENGLISH);
////		String formattedDate = outputFormatter.format(startdateTime);
////		String endFormatt=outputFormatter.format(end);
////		
////		System.out.println(formattedDate);
////		System.out.println(endFormatt);
////		
////		
////		System.out.println("testingggg...Burner Gas");
////		
////		BurnerGas();
////		
////		System.out.println("string q mark");
////		System.out.println(StringQuestionMark("??lz"));
////		
////		System.out.println("max task ");
////		
////		
////		
////		//PAYPAL Q-2 and  q1 check from hackerearth and check the previous time asked question and DP questions of excel 
////		//HURRY
//////		int t[][]={
//////				{2,8},
//////				{4,5},
//////				{5,1}
//////		};
//////		
//////		System.out.println(MaxTask(3,16,t));
////		
////		int t[][]={
////				{1,5},
////				{3,2},
////				{7,30},
////				{10,5},
////				{12,4}
////		};
////		
////		System.out.println(MaxTask(5,50,t));
////		
////		System.out.println("beautiful nums");
////		
////		System.out.println(solve(1,2));
////		
////		
////		// 
////		
////		
////		funnn();
////		
////		
////		
////		
////		
////		
////		
////	}
////	
////	private static void funnn() {
////
////		System.out.println("pallinnnn");
////		
////		String  s= "abc";
////		
////				int ans = 0;
////				int n = s.length();
////				int[]A=new int[n];
////				
////				char s1[]=s.toCharArray();
////
////				//for i=1:n
//////					A[i]=A[i-1]^(1<<(s[i-1]-97))
////				for(int i=1;i<n;i++){
////					A[i]=A[i-1]^(1<<(s1[i-1]-97));
////				}		
////				    
////
//////				for i=1:n
//////				    for j=i;n
//////				    		
//////				    		
//////				        x=A[j]^A[i-1]
//////				        if (x&(x-1)) == 0    //if x is a power of 2 or not 
//////				            ans++;
//////				        endif
//////				    endfor
//////				endfor
////				int x;
////				for(int i=1;i<n;i++){
////					for(int j=i;j<n;j++){
////						x=A[j]^A[i-1];
////						if ((x&(x-1)) == 0){
////							 ans++;
////						}
////								
////					}
////				}
////				
////				System.out.println(ans);
////				
////	}
////
////	static long solve(int l, int r) {
////		// Your code goes here
////		long sum = 0;
////		HashSet<Integer> p = new HashSet<>();
////		HashSet<Integer> np = new HashSet<>();
////
////		while (l <= r) {
////
////			HashSet<Integer> c = new HashSet<>();
////
////			if (p.contains(l)) {
////				sum += l;
////			} else if (np.contains(l)) {
////
////			} else {
////
////				if (PerfectNum(l, c)) {
////
////					sum = sum + l;
////					if (!c.isEmpty()) {
////						p.addAll(c);
////					}
////				} else {
////					if (!c.isEmpty()) {
////						np.addAll(c);
////					}
////
////				}
////
////			}
////			l++;
////
////		}
////
////		return sum;
////
////	}
////
////	    static boolean PerfectNum(int num,HashSet<Integer> c){
////	        int count=20;
////	        while(num>1 ){
////	            if(c.contains(num) || count==0){
////	                return false;
////	            }
////	            c.add(num);
////	            num=square(num);
////	            count--;
////	        }
////	        return true;
////	    }
////
////	    static int square(int num){
////	        int sum=0;
////	        while(num>0){
////	            int r=num%10;
////	            sum+=(r*r);
////	            num=num/10;
////	        }
////	        return sum;
////	    }
////
////
////	static int MaxTask(int n, int t, int[][] task){
////		   PriorityQueue<Integer> pQueue= new PriorityQueue<>(Collections.reverseOrder());
////		   Arrays.sort(task,Comparator.comparingInt(o->o[0]));
////		   System.out.println("MAXIIII");
////
//////		   for(int i=0;i<task.length;i++){
//////			   for(int j=0;j<task[0].length;j++){
//////				   System.out.print(task[i][j]);
//////			   }
//////			   System.out.println("\n");
//////		   }
////		   
////		   
////		   int pQueueSum=0;
////		   int max=0;
////		   for(int i=0;i<n;i++){
////		       int totalTime =t;
////		       int distance = 2*task[i][0];
////		       int remainingTime=totalTime-distance;
////		       int currEffort=task[i][1];
////		       if(remainingTime<0){
////		           break;
////		       }
////		       while(pQueueSum>remainingTime){
////		           pQueueSum-=pQueue.poll();
////		       }
////		       if(pQueue.isEmpty()&&remainingTime>currEffort){
////		         pQueue.add(currEffort);
////		         pQueueSum+=currEffort;  
////		       }
////		       else if(pQueueSum+currEffort<=remainingTime){
////		           pQueue.add(currEffort);
////		           pQueueSum+=currEffort;
////		       }
////		       else{
////		           Integer currMax=pQueue.peek();
////		           if(currMax != null && currMax>currEffort){
////		               pQueue.poll();
////		               pQueue.add(currEffort);
////		               pQueueSum=pQueueSum-currMax+currEffort;
////		           }
////		       }
////		       max=Math.max(max,pQueue.size());
////		   }
////		return max;
////		}
////	
////	private static int StringQuestionMark(String str) {
////		
////		char[] s=str.toCharArray();
////		int n=s.length;
////		if(s[0]=='?' && s[n-1]=='?'){
////		    int ans=0;
////		    for(char c='a';c<='z';c++){
////		        s[0]=s[n-1]=c;
////		        ans+=StringQuestionMark(s.toString());
////		    }
////		    return ans;
////		}
////		if(s[0]=='?'){
////		    s[0]=s[n-1];
////		    return StringQuestionMark(s.toString());
////		}
////		if(s[n-1]=='?'){
////		    s[n-1]=s[0];
////		    return StringQuestionMark(s.toString());
////		}
////		if(s[0]!=s[n-1]) return 0;
////
//////		vector<vector<int> >dp(n,vector<int>(26,0));
////		int[][] dp=new int[n][26];
////		dp[0][s[0]-'a']=1;
////		for(int i=1;i<n;i++){
////		    int sum=0;
////		    for(int j=0;j<26;j++) sum+=dp[i-1][j];
////		    if(s[i]=='?'){
////		        for(int j=0;j<26;j++) dp[i][j]=sum-dp[i-1][j]; // coz the current character can be anything but not the last character in the string
////		    }
////		    else{
////		        dp[i][s[i]-'a']=sum-dp[i-1][s[i]-'a']; // if we have a definite character then count all cases where the previous character was different
////		    }
////		}
////		
////		int ans=0;
////		for(int i=0;i<n;i++) ans+=dp[n-1][i];
////
////		return ans;
////		
////	}
////	
////	
////	
////
////	private static void BurnerGas() {
//////		int N=3, K=2;
////		
//////		int[] X={3,3,3};
////		
////		int N=5, K=3;
////		int[] X={10,10,6,9,3};
////		
////		Arrays.sort(X);
////		
////		//sort(X.begin(),X.end(),greater<int>());
////		int s=0,a=0,c=1;
////		for(int i=K;i<N;i++)
////			s+=X[i];
////		for(int i=K-1;i>0;i--){
////			if(s>=c*(X[i-1]-X[i])){
////				s-=c*(X[i-1]-X[i]);
////				c++;
////				a=X[i-1];
////			}else{
////				a+=s/c;
////				s=0;
////				break;
////			}
////		}
////		if(s>0)
////			a+=s/c;
////		
////		System.out.println("answer"+a);
////		
////	}
////
////	private static int score(HashMap<Character, List<Character>> hm, Character folder, HashMap<Character, Integer> memo) {
////		
////		if(hm.get(folder).size()==0){
////			return 1;
////		}
////
////		int sum=0;
////		for(Character e:hm.get(folder)){
////			sum+=score(hm,e,memo);
////		}
////		
////		return 1+sum;
////		
////	}
////
////	static int findMinDaysUsingMath(int n) {
////	    return (int) Math.ceil(Math.log(n) / Math.log(2)) + 1;
////	}
////
////	static int findMinDaysUsingProgram(int n) {
////		if (n == 1) {
////			return 1;
////		} else if (n == 2) {
////			return 2;
////		} else {
////			int num_of_days = 1;
////			int x = 1;
////			while (num_of_days < n) {
////				x = x * 2;
////				if (x >= n) {
////					return num_of_days + 1;
////					//break;
////				}
////
////				num_of_days += 1;
////			}
////		}
////		
////		return 0;
////
////	}
////}
//
//
//import java.util.ArrayList;
//import java.util.HashMap;
//  
//public class Test{
//  
//// Function to find the length of
//// smallest substring of a having
//// string b as a subsequence
//static int minLength(String a, String b)
//{
//      
//    // Stores the characters present
//    // in string b
//    HashMap<Character, Integer> Char = new HashMap<>();
//  
//    for(int i = 0; i < b.length(); i++)
//    {
//        Char.put(b.charAt(i),
//                 Char.getOrDefault(b.charAt(i), 0) + 1);
//    }
//  
//    // Find index of characters of a
//    // that are also present in string b
//    HashMap<Character, ArrayList<Integer>>
//        CharacterIndex = new HashMap<>();
//  
//    for(int i = 0; i < a.length(); i++) 
//    {
//        char x = a.charAt(i);
//  
//        // If character is present in string b
//        if (Char.containsKey(x)) 
//        {
//            if (CharacterIndex.get(x) == null) 
//            {
//                CharacterIndex.put(
//                    x, new ArrayList<Integer>());
//            }
//              
//            // Store the index of character
//            CharacterIndex.get(x).add(i);
//        }
//    }
//  
//    int len = Integer.MAX_VALUE;
//  
//    // Flag is used to check if
//    // substring is possible
//    int flag;
//  
//    while (true)
//    {
//  
//        // Assume that substring is
//        // possible
//        flag = 1;
//  
//        // Stores first and last
//        // indices of the substring
//        // respectively
//        int firstVar = 0, lastVar = 0;
//  
//        for(int i = 0; i < b.length(); i++) 
//        {
//              
//            // For first character of string b
//            if (i == 0) 
//            {
//  
//                // If the first character of
//                // b is not present in a
//                if (CharacterIndex.containsKey(i))
//                {
//                    flag = 0;
//                    break;
//                }
//  
//                // If the first character of b
//                // is present in a
//                else
//                {
//                	int x=0;
//                	if(CharacterIndex.get(b.charAt(i)).size()!=0){
//                		
//                	
//                    x = CharacterIndex.get(b.charAt(i)).get(0);
//                	}
//                    // Remove the index from map
//                	if(CharacterIndex.get(b.charAt(i)).size()!=0){
//                		
//                	
//                    CharacterIndex.get(b.charAt(i)).remove(
//                        CharacterIndex.get(b.charAt(i)).get(0));
//                	}
//                    // Update indices of
//                    // the substring
//                    firstVar = x;
//                    lastVar = x;
//                }
//            }
//  
//            // For the remaining characters of b
//            else 
//            {
//                int elementFound = 0;
//					for (int e : CharacterIndex.get(b.charAt(i))) 
//                {
//                    if (e > lastVar)
//                    {
//                          
//                        // If index possible for
//                        // current character
//                        elementFound = 1;
//                        lastVar = e;
//                        break;
//                    }
//                }
//                if (elementFound == 0)
//                {
//                      
//                    // If no index is possible
//                    flag = 0;
//                    break;
//                }
//            }
//        }
//  
//        if (flag == 0)
//        {
//  
//            // If no more substring
//            // is possible
//            break;
//        }
//  
//        // Update the minimum length
//        // of substring
//        len = Math.min(
//            len, Math.abs(lastVar - firstVar) + 1);
//    }
//  
//    // Return the result
//    return len;
//}
//  
//
//
//// Driver code
//public static void main(String[] args)
//{
//      
//    // Given two string
//    String a = "ABCDEFDIVGHIJKLMNICPCOPQRSTUVWXYZO";
//    String b = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
//  
//    System.out.println("helo");
//    int len =0; 
//    		len=minLength(a, b);
//  System.out.println(len);
//    if (len != Integer.MAX_VALUE) 
//    {
//        System.out.println(len);
//    }
//    else 
//    {
//        System.out.println("Impossible");
//    }
//}
//}


// Java implementation of above approach
import java.io.*;
import java.util.*;

public class Test {

// Stores the dp-states
static int[][] dp = new int[100][100];

// Function to find the smallest subString in String A which
// contains String B as a subsequence.
static String smallestSubstring(String A, String B)
{
	
	// Size of String A
	int a = A.length();

	// Size of String B
	int b = B.length();

	// Initializing the first column of dp array.
	// Storing the occurence of first character of String B
	// in first (i + 1) characters of String A.
	for (int i = 0; i < a; ++i) {

	// If the current character of String A does not
	// match the first character of String B.
	if (i > 0 && A.charAt(i) != B.charAt(0)) {
		dp[i][0] = dp[i - 1][0];
	}

	// If the current character of String A is equal to
	// the first character of String B.
	if (A.charAt(i) == B.charAt(0)) {
		dp[i][0] = i;
	}
	}

	// Iterating through remaining characters of String B.
	for (int j = 1; j < b; ++j) {

	// Checking if any character in String A matches
	// with the current character of String B.
	for (int i = 1; i < a; ++i) {

		// If there is a match, then starting index of
		// required subString in String 'A' is equal to
		// the starting index when first 'j - 1'
		// characters of String 'B' matched with first
		// 'i - 1' characters of String 'A'.
		if (A.charAt(i) == B.charAt(j)) {
		dp[i][j] = dp[i - 1][j - 1];
		}

		// Else, starting index of required subString in
		// String 'A' is equal to the starting index
		// when first 'j' characters of String 'B'
		// matched with first 'i - 1' characters of
		// String 'A'.
		else {
		dp[i][j] = dp[i - 1][j];
		}
	}
	}

	// String for storing final answer
	String answer = "";

	// Length of smallest substring
	int best_length = 100000000;

	for (int i = 0; i < a; ++i) {

	// dp[i][b-1] is the index in String 'A', such that
	// the subString A(dp[i][b-1] : i) contains string
	// 'B' as a subsequence.
	if (dp[i][b - 1] != -1) {

		// Starting index of substring
		int start = dp[i][b - 1];

		// Ending index of substring
		int end = i;

		// Length of substring
		int current_length = end - start + 1;

		// if current length is lesser than the best
		// length update the answer.
		if (current_length < best_length) {
		best_length = current_length;

		// Update the answer
		answer = A.substring(start, best_length+1);
		}
	}
	}

	// Return the smallest substring
  System.out.println(answer.length());
	return answer;
}

// This function is initializing dp with -1
// and printing the result
static void smallestSubstringUtil(String A, String B)
{
	// Initialize dp array with -1
	for(int i=0;i<100;i++)
	{
	for(int j=0;j<100;j++)
	{
		dp[i][j] = -1;
	}
	}

	// Function call
	System.out.print( smallestSubstring(A, B) );
}

// Driver Code
public static void main(String[] args)
{
	// Input strings
	String A = "FORCESABCDEFDIVGHIJKLMNOPQRSTUVWXYZ";
	String B = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

	// Function Call
	smallestSubstringUtil(A, B);
}
}

// This code is contributed by sanjoy_62.

