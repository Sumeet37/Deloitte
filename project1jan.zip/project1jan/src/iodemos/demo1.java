package iodemos;

import java.io.File;
import java.io.IOException;

public class demo1 {

	public static void main(String[] args) throws IOException {
		
	
	File folder=new File("C:\\Deloitte\\folder\\subfolder\\subsub");
	
	File file=new File("C:\\\\Deloitte\\\\folder\\\\subfolder\\\\subsub\\newfile.txt");

	if(file.exists()) {
		System.out.println("file does exist");
		file.delete();
		
	}else {
		folder.mkdirs();
		file.createNewFile();
		System.out.println("file and folder created ");
		
	}
	
	
	
	}
}
