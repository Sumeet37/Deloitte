//transient variable used in customer

package iodemos;

import java.io.*;
public class DeserializationMain {

	public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {
		Customer customer=new Customer();
		
		ObjectInputStream stream=new ObjectInputStream(new BufferedInputStream(new FileInputStream(new File("delu.txt"))));
		
		customer=(Customer)stream.readObject();
		System.out.println(customer);
		
		stream.close();
	}
}
