package JDBC;

import java.sql.*;


public class CustomerInsertUsingResultset{
public static void main(String[] args) throws SQLException {

	Customer customer=new Customer();
	customer.accept();
	
	Connection connection=DBConnection.makeConnection();
//	String query="Insert into hr.customer values(?,?,?,?)";
	Statement statement =  connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,  ResultSet.CONCUR_UPDATABLE);
	
	ResultSet rs = statement.executeQuery("SELECT hr.customer.* FROM hr.customer");
	
	// insertion
	
	rs.moveToInsertRow();
    rs.updateInt("CUSTOMERID", customer.getCustomerId());
    rs.updateString("CUSTOMERNAME", customer.getCustomerName());
    rs.updateString("CUSTOMERADDRESS", customer.getCustomerAddress());
    rs.updateInt("BILLAMOUNT", customer.getBillAmount());
    rs.insertRow();
	
    //updation
    
    rs.absolute(1);
    rs.updateString(2,"Sumeet");
    rs.updateRow();
    
    
	connection.close();
	statement.close();
	
	
	
	
}



	
}
