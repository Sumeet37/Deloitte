package com.dec24.exercise;

import java.util.Scanner;
import java.util.StringTokenizer;

public class StringExercise {
 
//public static void display(String sentence) {
//	System.out.println(sentence);
//}
 public static void utility(String sentence) {
	
	 System.out.println("1 "+sentence.charAt(12));
//	 (Character.toString());
//	 boolean b=;
	 System.out.println("2 "+sentence.contains("is"));
	 sentence=sentence.concat("and killed it");
	 
	 System.out.println("3 "+sentence);
	 sentence.endsWith("dogs");
	 
	 System.out.println("4 "+sentence.equals("The quick brown Fox jumps over the lazy Dog"));
	 
	 System.out.println("5 "+sentence.equals("THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG"));
	 
	 System.out.println("6 "+sentence.length());
	 
	 System.out.println("7 "+sentence.matches("The quick brown Fox jumps over the lazy Dog"));
	 
	 System.out.println("8 "+sentence.replaceAll("The","A"));
	 
	 String[] splitter=new String[2];
	 splitter=sentence.split("fox");
	 System.out.println("9 "+splitter[0]+"\n"+splitter[1]);
	 //
	 
	 StringTokenizer st=new StringTokenizer(sentence," ");
	 String s;
	 System.out.print("10 ");
	 while (st.hasMoreTokens()) {
		 s=st.nextToken();
		 
		if(s.equals("fox") || s.equals("FOX") || s.equals("dog") || s.equals("DOG") ) {
			System.out.println(s);
		}
	}
	 ////
	 System.out.println("11 "+sentence.toLowerCase());
	 
	 System.out.println("12 "+sentence.toUpperCase());
	 
//	 while
	 System.out.println("13 "+sentence.indexOf('a'));
	 
	 System.out.println("14 "+sentence.lastIndexOf('e'));
 
 }
public static void main(String[] args) {
//	Scanner scanner=new Scanner(System.in);
	String sentence="The quick brown fox jumps over the lazy dog";
	utility(sentence);
}
}
