import java.util.*;
import java.util.stream.Collectors;

//import java.util.Arrays;
//
////import java.util.HashMap;
////
//////EXPEDIA
//////////
//////////class A{
//////////	
//////////}
//////////
//////////class B{
//////////	
//////////}
////////
////////
////////public class Test1 {
////////
////////	public static void main(String[] args) {
////////		// TODO Auto-generated method stub
////////String d="f";
////////System.out.println(20/10%2);
////////	}
////////
////////}
//////
//////class Test1
//////
//////{
//////
//////static String reverse(String s)
//////
//////{
//////
//////char[] letters = new char[s.length()];
//////
////// int ind = 0;
//////
////// for(int i = s.length() - 1; i >= 0; i--)
//////
////// {
//////
////// letters[ind] = s.charAt(i);
//////
////// ind++;
//////
////// }
//////
////// String reversed = "";
//////
//////  for(int i = 0; i < s.length(); i++)
//////
//////  {
//////
//////  reversed = reversed + letters[i];
//////
//////  }
//////
//////return reversed;
//////
//////}
//////
//////static boolean isPalindrome(String str)
//////
//////{
//////
////// if(reverse(str).equals(str))
//////
////// {
//////
////// return true;
//////
////// }
//////
////// else
//////
////// {
//////
////// return false;
//////
////// }
//////
//////}
//////
//////public static void main(String[] args)
//////
//////{
//////
////////Scanner sc = new Scanner(System.in);
//////
//////System.out.print("Enter a string:");
//////
//////String x = "aabb";
//////
////// if(isPalindrome(x))
//////
////// {
//////
////// System.out.println(x + " is a palindrome");
//////
////// }
//////
////// else
//////
////// {
//////
////// System.out.println(x + " is not a palindrome");
//////
////// }
//////
//////}
//////
//////}
////
////
////
////
////class Test1{
////	
////	
////	public static void main(String[] args) {
////		
//////		String str1 = "aabb";
//////		char[] str=str1.toCharArray();
//////		
//////		
//////		int palCount =0;// It keeps count of the palindrome
//////		for(int i=0;i<str.length;i++){ //Outer loop that is the start point of the substring
//////		
//////			HashMap<Character,Integer> myMap=new HashMap<>(); // To keep count of the characters
//////		int oddCountChar = 0; //Keep count of the characters which have the odd frequency
//////		for(int j =i;j<str.length;j++){
//////		if(j==i){ // Fo the initial substring i.e. when j==i no of characters with odd freq must be initialized to 1
////////			myMap[str[j]] =1;
//////			myMap.put(str[j],1);
//////		oddCountChar = 1;
//////		} else {
////////		myMap[str[j]]++;
//////			if(myMap.containsKey(str[j])){
//////				myMap.put(str[j], myMap.get(str[j])+1);
//////			}
//////			
//////			
////////		if(myMap[str[j]]%2 == 0)// If the count of a character has become even that means it was odd before
//////		if(myMap.containsKey(str[j]) && myMap.get(str[j])%2 == 0)
//////		oddCountChar--;
//////		else
//////		oddCountChar++; // If the count of a character has become odd that means it was even before
//////		}
//////		if((j-i+1)%2 == 0 && oddCountChar==0) //j-i+1 i.e. the length of the substring,if even then no charcaters should have odd frequency
//////		palCount++;
//////		else if((j-i+1)%2 != 0 && oddCountChar==1) //j-i+1 i.e. the length of the substring,if odd then no charcaters should have even frequency
//////		palCount++;
//////		}
//////		myMap.clear();
//////		}
////////		cout<<palCount<<endl;
//////		System.out.println(palCount);
////		
////		String s="bbrrg";
////		
////		int n = s.length();
////	    int answer = 0;
////	    HashMap<Integer, Integer> m=new HashMap<>();
////	    m.put(0,1);
////
////	    int x = 0;
////	    for (char c : s.toCharArray()) {
////	        int d = c - 'a';
////	        x ^= 1 << d;
////	        answer =answer+ m.getOrDefault(x,0);
////	        for (int i = 0; i < 26; ++i) {
////	            answer += m.getOrDefault(x ^ (1 << i),0);
////	        }
////	         m.put(x,m.getOrDefault(x,0)+1);
////	    }
////
////	    System.out.println(answer);
////	}
////	
////}
////
//// Java program to print minimum number that can be formed
//// from a given sequence of Is and Ds
//public class Test1
//{
//	
//	// Prints the minimum number that can be formed from
//	// input sequence of I's and D's
//	static void PrintMinNumberForPattern(String arr)
//	{
//		// Initialize current_max (to make sure that
//		// we don't use repeated character
//		int curr_max = 0;
//
//		// Initialize last_entry (Keeps track for
//		// last printed digit)
//		int last_entry = 0;
//
//		int j;
//
//		// Iterate over input array
//		for (int i = 0; i < arr.length(); i++)
//		{
//			// Initialize 'noOfNextD' to get count of
//			// next D's available
//			int noOfNextD = 0;
//
//			switch (arr.charAt(i))
//			{
//				case 'I':
//					// If letter is 'I'
//
//					// Calculate number of next consecutive D's
//					// available
//					j = i + 1;
//					while (j < arr.length() && arr.charAt(j) == 'D')
//					{
//						noOfNextD++;
//						j++;
//					}
//
//					if (i == 0)
//					{
//						curr_max = noOfNextD + 2;
//
//						// If 'I' is first letter, print incremented
//						// sequence from 1
//						System.out.print(" " + ++last_entry);
//						System.out.print(" " + curr_max);
//
//						// Set max digit reached
//						last_entry = curr_max;
//					}
//					else
//					{
//						// If not first letter
//
//						// Get next digit to print
//						curr_max = curr_max + noOfNextD + 1;
//
//						// Print digit for I
//						last_entry = curr_max;
//						System.out.print(" " + last_entry);
//					}
//
//					// For all next consecutive 'D' print
//					// decremented sequence
//					for (int k = 0; k < noOfNextD; k++)
//					{
//						System.out.print(" " + --last_entry);
//						i++;
//					}
//					break;
//
//				// If letter is 'D'
//				case 'D':
//					if (i == 0)
//					{
//						// If 'D' is first letter in sequence
//						// Find number of Next D's available
//						j = i + 1;
//						while (j < arr.length()&&arr.charAt(j) == 'D')
//						{
//							noOfNextD++;
//							j++;
//						}
//
//						// Calculate first digit to print based on
//						// number of consecutive D's
//						curr_max = noOfNextD + 2;
//
//						// Print twice for the first time
//						System.out.print(" " + curr_max + " " + (curr_max - 1));
//
//						// Store last entry
//						last_entry = curr_max - 1;
//					}
//					else
//					{
//						// If current 'D' is not first letter
//
//						// Decrement last_entry
//						System.out.print(" " + (last_entry - 1));
//						last_entry--;
//					}
//					break;
//			}
//		}
//		System.out.println();
//	}
//
//	// Driver code
//	public static void main(String[] args)
//	{
////		System.out.println("hello");
////		PrintMinNumberForPattern("M");
////		PrintMinNumberForPattern("MNM");
//		
//		System.out.println("hello");
//		
//	}
//	
//	int[] pos=new int[26];
//	String gstr;
//	int[] DP=new int[1000010];
//	int solve(int idx)
//	{
//	    if (DP[idx]!=-1)
//	        return DP[idx];
//	    if (gstr.charAt(idx)=='Z')
//	        return DP[idx]=idx;
//	    if (upper_bound(pos[gstr.charAt(idx)-'A'+1], pos[gstr.charAt(idx)-'A'+1], idx)!=pos[gstr.charAt(idx)-'A'+1])
//	        return DP[idx]=solve(*upper_bound(pos[gstr[idx]-'A'+1].begin(), pos[gstr[idx]-'A'+1].end(), idx));
//	    return DP[idx]=1e9;
//	    /*
//	     * if (upper_bound(pos[gstr.charAt(idx)-'A'+1].begin(), pos[gstr.charAt(idx)-'A'+1].end(), idx)!=pos[gstr.charAt(idx)-'A'+1].end())
//	        return DP[idx]=solve(*upper_bound(pos[gstr[idx]-'A'+1].begin(), pos[gstr[idx]-'A'+1].end(), idx));
//	    return DP[idx]=1e9;*/
//	}
//	int minSubstring(String s)
//	{
////	    memset(DP, -1, sizeof(DP));
//	    Arrays.fill(DP, -1);
//		
//	    gstr=s;
//	    for (int i=0; i<s.size(); i++)
//	        pos[s[i]-'A'].push_back(i);
//	    int ret=1e9;
//	    for (int i=0; i<pos[0].size(); i++)
//	        ret=min(ret,solve(pos[0][i])-pos[0][i]+1);
//	    return ret;
//	}
//}
//
//// This code is contributed by Princi Singh
//

public class Test1{
	
	public static void main(String[] args) {
		
		
		int[] arr1={1 ,2 ,5 ,4 , 3 , 6};
		int[] arr2={4 ,2 ,3 , 1 ,6 , 5};
		List<Integer> A = Arrays.stream(arr1).boxed().collect(Collectors.toList());
		List<Integer> B = Arrays.stream(arr2).boxed().collect(Collectors.toList());
		Test1 tt=new Test1();
		System.out.println(tt.solve(A,B));
		
	}
	
//	typedef pair <int ,int> ipair;
	pair ipair;
	List<pair> temp;
	
	class pair{
		int first;
		int second;
		pair(int a1,int b1){
			first=a1;
			second=b1;
		}
	}
	

	void merge(List<pair> vec , int st , int mid , int end ,List<Integer> ans){
	    int rc = 0 , l = st , r = mid + 1  , idx = st;
	    while(l <= mid && r <= end){
	        if(vec.get(l).first > vec.get(r).first){
//	            temp[idx] = vec[r];
	        	temp.set(idx, vec.get(r));
	            rc++ ; r++;
	        }
	        else{
//	            ans[vec.get(l).second] += rc;
	            ans.set(vec.get(l).second, ans.get(vec.get(l).second)+rc);
//	            //temp[idx] = vec[l];
	            temp.set(idx, vec.get(l));
	            l++;
	        }
	        idx++;
	    }
	    while(l <= mid){
//	        ans[vec.get(l).second] += rc;
	    	ans.set(vec.get(l).second, ans.get(vec.get(l).second)+rc);
//	        temp[idx] = vec[l];
	    	 temp.set(idx, vec.get(l));
	        l++ ; idx++;
	    }
	    while(r <= end){
	    	 temp.set(idx, vec.get(r));
	        rc++ ; r++ ; idx++;
	    }
	    for(int i = st ; i <= end ; i++){
	        //vec[i] = temp[i];
	        vec.set(i, temp.get(i));
	    }
	}


	void mergesort(List<pair> vec , int st , int end , List<Integer> ans){
	    if(st >= end)
	        return ;
	    int mid = st + (end-st)/2;
	    mergesort(vec ,  st , mid  , ans );
	    mergesort(vec , mid +1 , end , ans);
	    merge(vec , st , mid , end , ans);
	}

	List<Integer>  countsmaller(List<Integer> nums){
	    int n = nums.size();
	    temp=new ArrayList<pair>(n);
	    
	    List <pair> pairs=new ArrayList<>(n);
	    for(int i = 0 ; i < nums.size() ; i++){
	        pairs.add(new pair(nums.get(i) , i));
	    }
	    List<Integer> ans=new ArrayList<>(n);
	    mergesort(pairs , 0 , n-1 , ans);
	    return ans;
	}

	long solve(List<Integer> A , List<Integer> B){
	    int n = A.size();
//	    unordered_map <int,int> umap;
	    HashMap<Integer,Integer> umap=new HashMap<>();
	    
	    for(int i = 0 ; i < B.size(); i++){
//	        umap[B[i]] = i;
	    	umap.put(B.get(i), i);
	    }
	    
	    for(Integer val : A){
//	        val = umap[val]; 
	    	// replacing elements of A with their indices in B.
	    	val = umap.get(val); 
	    }
	    
	    List<Integer> ans = countsmaller(A);  // this contains no.of elements smaller to this to the right.
//	    long long int res =  0;
	    long res=0;
	    for(int i =0; i < A.size() ; i++){
	        int rightelements  = n - i -1 ;
	        int rightgreater   = (rightelements - ans.get(i));
	        int leftelements   = i;
	        int leftsmaller    = A.get(i) - ans.get(i);
	        
	        res += (rightgreater * leftsmaller);
	    }
	    return res;
	    
	}


	
	
	
}





