package com.dec24.overloading;

public class Calculator {

	public void add(int num1,int num2) {
		
		System.out.println(num1+num2);
	}
	public void add(int num1,double num2) {
		
		System.out.println(num1+num2);
	}
	public void add(double num1,int num2) {
		
		System.out.println(num1+num2);
	}
	public void add(double num1,double num2) {
		
		System.out.println(num1+num2);
	}
	
	public void sub(int num1,int num2) {
		
		System.out.println(num1-num2);
	}
	
	
public void sub(int num1,double num2) {
		
		System.out.println(num1-num2);
	}
public void sub(double num1,int num2) {
	
	System.out.println(num1-num2);
}
public void sub(double num1,double num2) {
	
	System.out.println(num1-num2);
}


public void mul(int num1,int num2) {
	
	System.out.println(num1*num2);
}
public void mul(double num1,int num2) {
	
	System.out.println(num1*num2);
}
public void mul(int num1,double num2) {
	
	System.out.println(num1*num2);
}
public void mul(double num1,double num2) {
	
	System.out.println(num1*num2);
}


public void div(int num1,int num2) {
	
	System.out.println(num1/num2);
}
public void div(double num1,int num2) {
	
	System.out.println(num1/num2);
}
public void div(int num1,double num2) {
	
	System.out.println(num1/num2);
}
public void div(double num1,double num2) {
	
	System.out.println(num1/num2);
}


public static void main(String[] args) {
	Calculator c=new Calculator();
	c.add(1,2);
	c.add(1.1,2);
	c.add(1,2.2);
	c.add(1.1,2.2);
	
	c.sub(2,1);
	c.sub(2.2,1);
	c.sub(2,1.1);
	c.sub(2.2,1.1);
	
	c.mul(1,2);
	c.mul(1.1,2);
	c.mul(1,2.2);
	c.mul(1.1,2.2);
	
	c.div(2,1);
	c.div(2.2,1);
	c.div(2,1.1);
	c.div(1.1,2.2);
}
}
