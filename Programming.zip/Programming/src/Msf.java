import java.util.ArrayList;
import java.util.Arrays;


class A1{
	
}
class B1 extends A1{
	
}
class C1 extends B1{
	
}

public class Msf {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		B1 b=new B1();
		
		System.out.println((b instanceof B1));
		System.out.println((b instanceof B1) && (!(b instanceof A1)));
		System.out.println((b instanceof B1) && (!(b instanceof C1)));
		
		

		int arr[]={5,3,5,7,8};
		
		int k=3;
//		int arr[]={1,2,3,3,4,5};
//		int k=3;
		
//		int arr[]={1,2,3,4};
//		int k=4;
	
		
//		System.out.println(fn(arr,k));
//		System.out.println(countSubArray(arr,3));
		
		int x = 0;
		int y = 0;
		for (int z = 0; z < 5; z++) {
			
			if ((++x > 2) || (++y > 2)) {
				x++;
			}
		}
		System.out.println(x + " " + y);
		
	}
	
	public static int countSubArray(int[] arr,int k)
	{
	int j = 1;
	int ans =0;
	int count=0;

		while(j<arr.length)
		{
			if(arr[j] > arr[j-1])
			{
				count++;
			}
			else
			{
				if(count+1 >= k)
				{
					ans += count-k+2;
					count=0;
				}
			}
			j++;
		}
		if(count+1 >= k)
			ans += count-k+2;
		return ans;
	}
	
	static int fn(int[] arr,int k){
	    
		int n=arr.length;
	    if(k==0||k>n) return 0;
	    int ans=0;
	    //vector<int> preCompute(n,-1);
	    //ArrayList<Integer> preCompute=new ArrayList<>();
	    int[] preCompute=new int[n];
	    Arrays.fill(preCompute, -1);
	    
	    int j=0;
	    int curr=0;
	    while(j<n-1){
	        if(arr[j+1]>arr[j]) curr++;
	        else{
	            preCompute[j-curr]=curr+1;
	            curr=0;
	        }
	        j++;
	    }
	    preCompute[j-curr]=curr+1;
	    for(int i=0;i<n;i++){
	        if(preCompute[i]!=-1&&preCompute[i]>=k) ans+=preCompute[i]-k+1;
	    }
		return ans;
	}

}
