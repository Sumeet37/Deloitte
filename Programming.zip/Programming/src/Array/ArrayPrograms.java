package Array;

import java.sql.Array;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import java.util.stream.Collector;
import java.util.stream.Collectors;

//class comp implements Comparator<Integer>{
//
//	
//	@Override
//	public int compare(Integer o1, Integer o2) {
//
//		if(ArrayPrograms.hash.get(o1) == ArrayPrograms.hash.get(o2)){
//			return 1;
//		}
//		return ArrayPrograms.hash.get(o2) - ArrayPrograms.hash.get(o1);
//	}
//	
//}

public class ArrayPrograms {

	static HashMap<Integer,Integer> hash=new HashMap();
	public static void main(String[] args) {
		
//		int[] inputArray = new int[] {111, 333, 555, 777, 333, 444, 555};
		
	
		//1.REVERSE 
		
		String s="hello";
		
		char arr[]=s.toCharArray();
		
		for(int left=0, right=arr.length-1;left<right;left++,right--){
			char temp=arr[left];
			arr[left]=arr[right];
			arr[right]=temp;
		}
		
		String rev="";
		for(int i=s.length()-1;i>=0;i--){
			rev=rev + s.charAt(i);		
		}	
		
		String s1=new String(arr);
		System.out.println(s1);
		System.out.println(rev);
//		equalityOfArrayCheck();
		
		
		//2.Ignore 1 char in array
		
		s="geeks For Geeks";
		int j, count = 0, n = s.length();
	    char []t = s.toCharArray();
		char[]z=new char[s.length()];
		for (int i = j = 0; i < n; i++)
	    {
	        if (t[i] != 'e')
	        z[j++] = t[i];
	        else
	            count++;
	    }
	     
//	    while(count > 0)
//	    {
//	        t[j++] = '\0';
//	        count--;
//	    }
	    System.out.println(z);
	    
	    //3.magic number 1234 div by 3
	    
	    
	    //4.Missing Number 
	    
	    int input[] = {1, 2, 4, 6, 3, 7, 8};
	    int prev=input[0];
	    int missing=-1;
//	    for(int i=1;i<input.length;i++){
//	    	if(input[i]-prev>1){
//	    		missing=(input[i]-1);
//	    		break;
//	    	}
//	    	prev=input[i];
//	    }
//	    if(missing==-1){
//	    	System.out.println("missing "+ input[0]);
//	    }else{
//	    
//	    System.out.println("missing "+ missing);
//	    }
	    
	    System.out.println(Math.log10(100));
	    
	    
	    //5.
	    //Trapping rain water problem
	    
	    TrapWater();
	    
	    SimpleTapWaterSolution();
	    
	    OptimalTapWaterSolution();
	    
	    
	    
	    //**************************
	    
	    //GEEKS FOR GEEKS ARRAY QUESTIONS //https://www.geeksforgeeks.org/practice-for-cracking-any-coding-interview/
	    
	    //Q7 Rotate array
	    //using gcd method 
	    
	    RotateGcd();
	    
	    //Q12
	    MinDistanceInArray();
	    
	    
	    //Q17 Maximum index
	    maximumIndex();
	    
	    
//	    Q18 max path in 2 array
	    
	    
	    //MY solution works fine on public test cases
	    MaxPathTwoArray();
	    
	    //better Solution
	    mergetSortTypeMaxPathTwoArray();
	    
	    
//	    Q19 Product array See copy for details
	    productArrayPuzzle();//math approach similar to pow(ele,-1)
	    
	    
	    //naive approach left and right array and prod array
	    //better approach without left and right array with prod array
	    productArrayIteration();
	    
	    //best approach without prod array 
	    
	    //Q21 
	    missingAndRepeatingElement();
	    
	    //Q22
	    stockbuySell1Iteration();
	    
	    stockbuySellInfiniteIteration();
	    
	    stockBuySellInfiniteIterationAndFee();
	    
	    
	    //Q24-II
	    CountPairDuplicateUnsorted();
	    
	    
	    //MISC SORT BY FREQUENCY // COMPARATOR
	    freqSort();
	    
	    
	    //sorting bubble
	    
	    
	    //DP
	    minCoins();
	    
	    //Recursion 
	    
	    System.out.println("COIN RECURSION");
//	    System.out.println(Integer.MAX_VALUE);
	    int coins[]={25, 10, 5};//{9, 6, 5, 1};//{25, 10, 5};
	    int V=30;
		int result = recursionMinCoin(V, coins);

		if (result == Integer.MAX_VALUE) {
			System.out.println(-1);
		} else {
			System.out.println(result);
		}
	    
		
		//bitwise 
		System.out.println("bitwise");
		int num=6;
		System.out.println(6 & 1);
		
	    //subsetSUm
		System.out.println("subset sum");
		int[] nums={2, 4, 5};
		findSubsets(0,nums,0);
		
		
		//75 question 
		//Array -  Container With Most Water
		
		ContainerWithMostWater();
		
		ContainerWithMostWaterOptm();
		
		
		roll();
	    
	}

	private static void roll() {
		// TODO Auto-generated method stub
		String s="abz";
		int arr[]={3};
		
//		System.out.println("roll");
		
		
		
		int n=s.length();
		
		
		int brr[] = new int[n+1];
		System.out.println("n+1"+brr.length);
		
		for(int i = 0; i < arr.length  ; i++){
			brr[0] += 1;
			brr[arr[i]] -= 1;	
			
		}
		
		for(int i = 1; i < n; i++){
			brr[i] += brr[i-1];
		}
		
		char c[]=s.toCharArray();
		
		char ch[] = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
		for(int i = 0; i < n; i++){
			int x = brr[i] % 26;
			int y = c[i] - 97;
			//c[i] = ch[(x+y)%26];
			int ii=((x+y)%26) + 97;
			
			c[i]=Character.toString((char)ii).charAt(0);
			
				//Character.toString((char)ii)	
			
		}
		
		System.out.println(new String(c));
		
	
		
	}

	private static void ContainerWithMostWaterOptm() {
		System.out.println("\nContainerWithMostWater OPTIMAL ");
		int [] height={1,8,6,2,5,4,8,3,7};
		
		int n=height.length;
        int maxVol=Integer.MIN_VALUE;
        
        int i=0;
        int j=n-1;
        
        while(i<j){
        	
        	int h=Math.min(height[i], height[j]);
            int l=j-i;
            int vol=h*l;
        	
        	maxVol=Math.max(maxVol, vol);
        	if(height[i]<height[j]){
        		i++;
        	}else{
        		j--;
        	}
        	
        	
        }
        
        System.out.println(maxVol);
        
        
        
        
		
	}

	private static void ContainerWithMostWater() {
		
		System.out.println("\nContainerWithMostWater");
		int [] height={1,8,6,2,5,4,8,3,7};
		
		int n=height.length;
        int maxVol=Integer.MIN_VALUE;
        for(int i=0;i<n;i++){
            for(int j=i+1;j<n;j++){
                
                int h=Math.min(height[i], height[j]);
                int l=j-i;
                int vol=h*l;
                
                maxVol=Math.max(maxVol, vol);
                
            }
        }
        
        System.out.println("max volume"+maxVol);
		
	}

	static void findSubsets(int sum,int[] nums,int index )
    {
      // Base Condition
        if (index == nums.length) {
//            subset.add(output);
        	System.out.print(sum);
            return;
        }
       
        // Not Including Value which is at Index
        findSubsets(sum,nums,index+1);
 
        // Including Value which is at Index
//        output.add(nums.get(index));
        //sum=0;
        
        findSubsets(sum+nums[index],nums,index+1);
    }
 
	
	private static int recursionMinCoin(int target,int[] coins) {
		
		if(target==0){
			return 0;
		}
//		if(target <0){
//			return Integer.MAX_VALUE;
//		}
		
		int minValue=Integer.MAX_VALUE;
		for(int i=0;i<coins.length;i++){
			if(target-coins[i]>=0){
				minValue=Math.min(minValue, recursionMinCoin(target-coins[i],coins));
			}
			
		}
		if(minValue!=Integer.MAX_VALUE){
			minValue=minValue+1;
		}
		
		return minValue;
		
		
	}
	public static void minCoins() 
	{ 
		System.out.println("min coins");
		int a[]={9, 6, 5, 1};//{25, 10, 5};
		int M=a.length;
		int V=11;//30;
	    // Your code goes here
	    int dp[]=new int[V+1];
	    
	    Arrays.fill(dp, Integer.MAX_VALUE);
	    dp[0]=0;
	    for(int i=0;i<M;i++){
	        for(int j=0;j+a[i]<V+1;j++){
	        	System.out.println(a[i]+"j="+j+"dp[j]="+dp[j]);
	        	if(dp[j]!=Integer.MAX_VALUE){
	        		dp[j+a[i]]=Math.min(dp[j+a[i]],(dp[j]+1));
	        	}
	            
	        }
	    }
	    System.out.println(Arrays.toString(dp));
	}
	
	
	private static void freqSort() {

		System.out.println("freq");
		
		int arr[]={2, 5, 2, 6, -1, 9999999, 5, 8, 8, 8};
		
		for (int i = 0; i < arr.length; i++) {
			if(hash.containsKey(arr[i])){
				hash.put(arr[i],hash.get(arr[i])+1);
			}else{
				hash.put(arr[i],1);
			}
		}
		System.out.println(hash);
		
//		arr=MergeSort(arr,0,arr.length-1);
		
		List<Integer> list=Arrays.stream(arr).boxed().collect(Collectors.toList());
		
//		Collections.sort(list,new comp());
		
//		System.out.println(list);
		
	}

	public static void stringSort(String str){
        int[] alphabets = new int[26];


        for(int i =0;i<str.length();i++){
            alphabets[str.charAt(i) - 'a']++;
        }

        Comparator<Character> comparator = (c1, c2) ->
        {
            if(Integer.valueOf(alphabets[c2 - 'a']).equals(alphabets[c1 - 'a'])){
              return  Character.valueOf(c2).compareTo(c1);
            }

            return Integer.valueOf(alphabets[c2 - 'a']).compareTo(alphabets[c1 - 'a']);
        };
        List<Character> charArray = new ArrayList<>();

        for (char c:
             str.toCharArray()) {
            charArray.add(c);
        }

        Collections.sort(charArray,comparator);

        str = String.valueOf(charArray);

        System.out.println(str);
    }


//	private static int[] MergeSort(int[] arr, int start, int end) {
//		
//		int mid=(start+end)/2;
//		int array1[]=MergeSort(arr,start,mid);
//		int array2[]=MergeSort(arr,mid+1,end);
//		
//		int result[]=Merge(array1,array2);
//		
//		
//	}

//	private static int[] Merge(int[] array1, int[] array2) {
//		
//		int i=0,j=0,k=0;
//		int temp[]=new int[array1.length+array2.length];
//		
//		while(i<array1.length && j<array2.length){
//			if(hash.get(array1[i]) > hash.get(array2[j]) ){
//				i++;
//				k++;
//			}else if(hash.get(array1[i]) > hash.get(array2[j])){
//				
//			}
//		}
//		
//		
//	}

	private static void CountPairDuplicateUnsorted() {
		
		System.out.println("COUNT PAIR ");
		int arr[]={1, 5, 7, -1};//{1, 5, 7, -1, 5};
		int sum=6;//2;//6;
		Arrays.sort(arr);
		System.out.println(Arrays.toString(arr));
		int i=0,j=arr.length-1;
		int count=0;
		while(i<j){
			if(arr[i]+arr[j]>sum){
				j--;
			}else if(arr[i]+arr[j]<sum){
				i++;
			}else{
				int temp=arr[i];
				int tempIndex=i;
				
				while(arr[tempIndex]==temp && tempIndex<j){
					count++;
					tempIndex++;
					
				}
				j--;
				
			}
		}
		
		System.out.println("pairs= "+count);
	}

	private static void stockBuySellInfiniteIterationAndFee() {
		
		System.out.println("TRANSACTION FEE stock problem multiple iteration");
		int arr[] = {1,3,2,8,4,9};//{11,6,7,19,4,1,6,18,4};//{7,1,5,3,6,4};//{7,6,4,3,1};//{1,3,7,5,10,3};
		int fee=2;
		
		int buy=0,sell=0,temp=0;
		
		int sum=0;
		boolean booked=false;
		for (int i = 1; i < arr.length; i++) {
			System.out.println("buy="+arr[buy]+" sell="+arr[sell]+" temp="+arr[temp]);
			if(arr[i]>=arr[i-1]){
				
				if(buy!=temp){
					if(arr[temp]-arr[sell]>=fee){
						//book
						System.out.println("booked "+((arr[temp]-arr[buy])-fee));
						sum=sum+(arr[temp]-arr[buy])-fee;
						//reset
						buy=temp=sell;
					}else{
						temp=buy;
					}
					
					
				}
				sell++;
				
			}else if (arr[i]<arr[i-1]){
				
				sell++;
				if(buy==temp){
					temp=i-1;
					
				}
			}
			
		}
		
		System.out.println(sum);
		
	}

	private static void stockbuySellInfiniteIteration() {
		System.out.println("stock problem multiple iteration");
		int arr[] = {11,6,7,19,4,1,6,18,4};//{7,1,5,3,6,4};//{7,6,4,3,1};
		
		int min=Integer.MAX_VALUE;
		int sum=0;
		for (int i = 0; i < arr.length; i++) {
			if(arr[i]<min){
				min=arr[i];
			}else{
				System.out.println("peaks"+(arr[i]-min));
				sum=sum+(arr[i]-min);
				min=arr[i];
			}
		}
		System.out.println(sum);
		
	}

	private static void stockbuySell1Iteration() {
		// TODO Auto-generated method stub
		System.out.println("stock problem ");
		int arr[] = {7,1,5,3,6,4};//{7,6,4,3,1};
		int min=Integer.MAX_VALUE;
		int maxProfit=0;
		
		for (int i = 0; i < arr.length; i++) {
			if(arr[i]<min){
				min=arr[i];
			}else{
				maxProfit=Math.max(maxProfit, arr[i]-min);
				
			}
		}
		System.out.println(maxProfit);
		
		
	}

	private static void missingAndRepeatingElement() {

		System.out.println("msiing and repeating element");
		int arr[] = {2,2};//{4, 3, 6, 2, 1, 1};
		int n=arr.length;
		for (int i = 0; i < arr.length; i++) {
			int index=(arr[i]-1)% n;
			arr[index]=arr[index]+n;
		}
		System.out.println("hello"+Arrays.toString(arr));
		int result[]=new int[2];
		
		for (int i = 0; i < arr.length; i++) {
			if((arr[i]-1)/n==2){
				//duplicate
//				System.out.println("dup"+arr[i]);
				result[0]=i+1;
			}else if((arr[i]-1)/n==0){
				//missing
				result[1]=i+1;
			}
		}
		
		System.out.println("duplicate missing  are"+Arrays.toString(result));
		
	}

	private static void productArrayIteration() {
		System.out.println("prod Array optimized");
		
		int a[] = {1, 2, 3, 4, 5};//{10, 3, 5, 6, 2};
		int n=a.length;
		int prod[]=new int[a.length];
		
		prod[0]=1;
		for (int i = 1; i < a.length; i++) {
			prod[i]=prod[i-1]*a[i-1];
		}
//		System.out.println(Arrays.toString(prod));
		
//		int rightMul=1;
//		for (int j=n-2;j>=0;j--) {
//			rightMul=rightMul*a[j+1];
//			prod[j]=prod[j]*rightMul;
//		}
		
		
		  int rightMul=1; 
		  for (int j=n-1;j>=0;j--) {
		  
		  prod[j]=prod[j]*rightMul; rightMul=rightMul*a[j];
		   
		  }
		 
		
		
		
		System.out.println(Arrays.toString(prod));
		
		
	}

	private static void productArrayPuzzle() {
		
		System.out.println(Math.pow(2, -1));
		double EPS = 1e-9;
		
		
		
		int a[] = {10, 3, 5, 6, 2};
		int n=a.length;
		double sum = 0;
        for (int i = 0; i < n; i++)
            sum += Math.log10(a[i]);
		
		for (int i = 0; i < n; i++)
			System.out.println((int) (EPS + Math.pow(10.00, sum - Math.log10(a[i]))) + " ");
		
		
		
		
	}

	private static void mergetSortTypeMaxPathTwoArray() {
		System.out.println("MaxPath Optimized");
		int arr1[] = {2, 3, 7, 10, 12, 15, 30, 34};//{10, 12};//{2, 3, 7, 10, 12};//{2, 3, 7, 10, 12, 15, 30, 34};
		int arr2[] = {1, 5, 7, 8, 10, 15, 16, 19};//{5, 7, 9};//{1, 5, 7, 8};//{1, 5, 7, 8, 10, 15, 16, 19};
		
		int m=arr1.length;
		int n=arr2.length;
		int i=0,j=0;
		int sum1=0,sum2=0,result=0;
		while (i<m && j<n) {
			//process smallest
			if(arr1[i]<arr2[j]){
				sum1+=arr1[i];
				i++;
			}else if(arr2[j]<arr1[i]){
				sum2+=arr2[j];
				j++;
			}else{
				result=result+Math.max(sum1, sum2)+arr1[i];
//				System.out.println(result);
				sum1=sum2=0;
				i++;
				j++;
			}
			
		}
		
		if(j==n){
			for (; i < m; i++) {
				sum1+=arr1[i];
			}
			
		}else if(i==m){
			for (; j < n; j++) {
				sum2+=arr2[j];
			}
		}
//		System.out.println(Math.max(sum1, sum2));
		result=result+ Math.max(sum1, sum2);
//		System.out.println("result= "+result);
		
		
	}

	private static void MaxPathTwoArray() {
		// TODO Auto-generated method stub
//		System.out.println("MaxPath");
		int arr1[] = {10, 12};//{2, 3, 7, 10, 12};//{2, 3, 7, 10, 12, 15, 30, 34};
		int arr2[] = {5, 7, 9};//{1, 5, 7, 8};//{1, 5, 7, 8, 10, 15, 16, 19};
		
		
		Set<Integer> set=Arrays.stream(arr1).boxed().collect(Collectors.toSet());
//		Set<Integer> set=new HashSet<Integer>();
//		for (int i = 0; i < arr1.length; i++) {
//			set.add(arr1[i]);
//		}
		
		
		List<Integer> dups=new ArrayList();
		for (int i = 0; i < arr2.length; i++) {
			if(set.contains(arr2[i])){
				dups.add(arr2[i]);
			}
		}
		
		int sum1[]=new int[dups.size()+1];
		int sum2[]=new int[dups.size()+1];
		
		int sum=0;
		//&& s<sum1.length && d<dups.size()
		for (int i = 0,s=0,d=0; i < arr1.length ; i++) {
//			System.out.println("i= "+i +" s= "+s +" d= "+d);
			if(d<dups.size() && arr1[i]==dups.get(d)){
				sum1[s]=sum;
				s++;
				sum=0;
				d++;
//				sum=sum+arr1[i];
			}
			
			sum=sum+arr1[i];
			
		}
		sum1[sum1.length-1]=sum;
		
		sum=0;
		for (int i = 0,s=0,d=0; i < arr2.length ; i++) {
			System.out.println("i= "+i +" s= "+s +" d= "+d);
			if(d<dups.size() && arr2[i]==dups.get(d)){
				sum2[s]=sum;
				s++;
				sum=0;
				d++;
//				sum=sum+arr1[i];
			}
			
			sum=sum+arr2[i];
			
		}
		sum2[sum2.length-1]=sum;
		
		
		sum=0;
		for (int i = 0; i < sum1.length; i++) {
//			System.out.println("MAX= "+Math.max(sum1[i], sum2[i]));
			sum=sum+Math.max(sum1[i], sum2[i]);
			
		}
		
		System.out.println(sum);
		
//		System.out.println("SUM1"+Arrays.toString(sum1) + " SUM2=  "+Arrays.toString(sum2));
		
		
//		System.out.println(set);
		
	}

	private static void maximumIndex() {
		System.out.println("MaxIndex Program");
		
		//IT WONT WORK IF ARRAY CONTAINS DUPLICATES coz we have used hashmap
		
		int arr[]={49, 49, 19, 41, 71, 98, 72, 69, 9, 38, 8, 72, 21, 79, 77};
		
		HashMap<Integer,List> index=new HashMap<Integer,List>();
		
		for (int i = 0; i < arr.length; i++) {
			
			if(index.containsKey(arr[i])){
				index.get(arr[i]).add(i);
			}else{
				index.put(arr[i],new ArrayList());
				index.get(arr[i]).add(i);
			}
			
			
		}
		
		
		
		Arrays.sort(arr);
		
		for (int i = 0; i < arr.length; i++) {
			
			if (index.get(arr[i]).size() > 1) {
				int temp = (Integer) index.get(arr[i]).get(0);
				index.get(arr[i]).remove(0);
				arr[i] = temp;

			} else {
				arr[i] = (Integer) index.get(arr[i]).get(0);
			}
		}
		
		int minIndex=arr[0];
		arr[0]=-1;
		int largestLength=-1;
		
		
		for (int i = 1; i < arr.length; i++) {
			if(arr[i]<minIndex){
				minIndex=arr[i];
				arr[i]=-1;//unnecessary
				
			}else{
				
				if(arr[i]-minIndex>largestLength){
					largestLength=arr[i]-minIndex;
				}
				
				arr[i]=arr[i]-minIndex;//unnecessary
				
			}
		}
		System.out.println(Arrays.toString(arr));
		
		System.out.println(largestLength);
		
		
//		int maxDiff = Integer.MIN_VALUE;
//	    int temp = arr.length;
//	     
//	    // Iterate from 0 to n - 1
//	    for(int i = 0; i < arr.length; i++)
//	    {
//	        if (temp > (Integer)index.get(arr[i]).get(0))
//	        {
//	            temp = (Integer)index.get(arr[i]).get(0);
//	        }
//	        maxDiff = Math.max(maxDiff,
//					(Integer) index.get(arr[i]).get(index.get(arr[i]).size() - 1) - temp);
//	        
//		maxDiff = Math.max(maxDiff, 
//				hashmap.get(arr.get(i)).get(hashmap.get(arr.get(i)).size() - 1) - temp
//				
//				);
//	        //[8].get(0)-8
//	    }
//	    return maxDiff;
		
		
		
		
	}

	private static void MinDistanceInArray() {
		
		//better solutions in copy
		
		System.out.println("Q12");
//		int arr[] = {2, 5, 3, 5, 4, 4, 2, 3};
//		int x=3,y=2;
//		int arr[]={3, 5, 4, 2, 6, 5, 6, 6, 5, 4, 8, 3};
//		int x=3,y=6;
		
		int arr[]={3, 4, 5};
		int x=3,y=5;
		
		int len,xi=-1,yi=-1;
		len=Integer.MAX_VALUE;
		for (int i = 0; i < arr.length; i++) {
			if(arr[i]==x){
				for (int j = 0; j < arr.length; j++) {
					if(arr[j]==y && Math.abs(i-j)<len){
						xi=i;
						yi=j;
						len=Math.abs(i-j);
						
					}
				}
				
			}
			
		}
		
		if(len!=Integer.MAX_VALUE){
			System.out.println("len="+len+" xi= "+xi+" yi= "+yi);
		}
		
	}

	private static void RotateGcd() {
		
		
	    		 
	}

	private static void OptimalTapWaterSolution() {
		/*
		 * Create two arrays left and right of size n. create a variable max_ = INT_MIN.
Run one loop from start to end. In each iteration update max_ as max_ = max(max_, arr[i]) and also assign left[i] = max_
Update max_ = INT_MIN.
Run another loop from end to start. In each iteration update max_ as max_ = max(max_, arr[i]) and also assign right[i] = max_
		 * 
		 * */
		
		
		int arr[]={0, 1, 0, 2, 1, 0, 1, 3, 2, 1, 2, 1};
		int n=arr.length;
		// left[i] contains height of tallest bar to the
        // left of i'th bar including itself
        int left[] = new int[n];
 
        // Right [i] contains height of tallest bar to
        // the right of ith bar including itself
        int right[] = new int[n];
 
        // Initialize result
        int water = 0;
 
        // Fill left array
        left[0] = arr[0];
        for (int i = 1; i < n; i++)
            left[i] = Math.max(left[i - 1], arr[i]);
 
        // Fill right array
        right[n - 1] = arr[n - 1];
        for (int i = n - 2; i >= 0; i--)
            right[i] = Math.max(right[i + 1], arr[i]);
 
        // Calculate the accumulated water element by element
        // consider the amount of water on i'th bar, the
        // amount of water accumulated on this particular
        // bar will be equal to min(left[i], right[i]) - arr[i] .
        for (int i = 0; i < n; i++)
            water += Math.min(left[i], right[i]) - arr[i];
 
        System.out.println(water);

		
		
	}

	private static void SimpleTapWaterSolution() {
		/*
		 * Traverse the array from start to end.
For every element, traverse the array from start to that index and find the maximum height (a) and traverse the array from the current index to end, and find the maximum height (b).
The amount of water that will be stored in this column is min(a,b) � array[i], add this value to the total amount of water stored
Print the total amount of water stored.
		 * 
		 * */
		int arr[]={0, 1, 0, 2, 1, 0, 1, 3, 2, 1, 2, 1};
		int n=arr.length;
		
		int res = 0;
		 
	    // For every element of the array
	    // except first and last element
	    for(int i = 1; i < n - 1; i++)
	    {
	         
	        // Find maximum element on its left
	        int left = arr[i];
	        for(int j = 0; j < i; j++)
	        {
	            left = Math.max(left, arr[j]);
	        }
	 
	        // Find maximum element on its right
	        int right = arr[i];
	        for(int j = i + 1; j < n; j++)
	        {
	            right = Math.max(right, arr[j]);
	        }
	 
	        // Update maximum water value
	        res += Math.min(left, right) - arr[i];
	    }
	    System.out.println(res); 
		
	}

	private static void TrapWater() {
		
		System.out.println("Trap Water");
//		int arr[]   = {3, 0, 2, 0, 4};
		int arr[]={0, 1, 0, 2, 1, 0, 1, 3, 2, 1, 2, 1};
		int m=3;//max in array
		int n=arr.length;
		
		int d2[][]=new int[m][n];
		
		//fill 2d array
//		for (int i = m-1; i >=0; i--) {
//			for (int j = n-1; j >=0; j--) {
//				d2[i][j]
//				
//			}
//		}
		for (int k = 0; k < arr.length; k++) {
			
			for(int i=m-arr[k];i<m;i++){
				d2[i][k]=1;
			}
			
		}
		List l;
		int water=0;
		int prevIndex;
		for (int i = 0; i < m; i++) {
			
			l=new ArrayList();
			prevIndex=-1;
			for (int j = 0; j < n; j++) {
				if(d2[i][j]==1){
					l.add(j);
					if(prevIndex==-1){
						prevIndex=j;
					}else{
						int diff=j-prevIndex-1;
						System.out.println("diff is " + diff + "j="+j+"prev="+prevIndex);
						water=water+diff;
						prevIndex=j;
					}
					
				}
				
			}
//			if(l.size()>1){
//				
//			}
			System.out.println(l);
			
		}	
		
		
		
		
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {
				
				System.out.print(d2[i][j] +" ");
			}
			System.out.println();
		}
		
		System.out.println("answer is ="+water);
		
	}

	static void equalityOfArrayCheck() {
		
		int[] arrayOne = {2, 5, 1, 7, 4};
		int[] arrayTwo = {2, 5, 1, 7, 4};
		
		if(arrayOne.length!=arrayTwo.length){
		}
		
		for (int i = 0; i < arrayOne.length; i++) {
			
		}
		
	}

	
	
	

}
