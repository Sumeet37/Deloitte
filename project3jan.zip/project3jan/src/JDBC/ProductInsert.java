package JDBC;

import java.sql.*;
import java.util.*;

public class ProductInsert {

	public static void main(String[] args) throws SQLException {
		
		Product product=new Product();
		product.accept();

		Connection connection=DBConnection.makeConnection();
		String query="insert into hr.product values(?,?,?,?)";
		
		PreparedStatement statement=connection.prepareStatement(query);
		
		statement.setInt(1,product.getProductId());
		statement.setString(2,product.getProductName());
		statement.setInt(3,product.getPrice());
		statement.setInt(4,product.getQoh());
		
		statement.executeUpdate();
		
		System.out.println(product.getProductName()+" ,  record inserted sucessfully!!");
		
		
	}
}
