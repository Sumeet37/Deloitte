package CollectionPackage;

import java.util.*;

public class HashMapdemo {

	public static void main(String[] args) {
		
	
	Map<String,Double> hm=new HashMap<String,Double>();
	
	hm.put("John Doe",new Double(3434.34));
	hm.put("Tom smith",123.22);
	hm.put("Jane Baker",new Double(1378.00));
	hm.put("Todd Hall",99.22);
	hm.put("Ralph Smith",-19.08);
	
	System.out.println(hm.get("John Doe"));
	System.out.println(hm);
	
	//iterating over map using KEYSET
	
	Set set=hm.entrySet();
	
	Iterator iterator=set.iterator();
	
	while(iterator.hasNext()) {
		Map.Entry me=(Map.Entry)iterator.next();
		System.out.println(me.getKey()+":");
		System.out.println(me.getValue());
				
	}
	
	//update
	
	double balance=((Double) hm.get("John Doe")).doubleValue();
	
	hm.put("John Doe",balance+1000);
	
	System.out.println(hm);
	
	}
}