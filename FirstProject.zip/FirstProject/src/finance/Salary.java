package finance;

public class Salary {
public int calculateSalary(int b,int pf) {
	return b+pf;
}
}
