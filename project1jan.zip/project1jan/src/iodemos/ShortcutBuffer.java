package iodemos;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ShortcutBuffer {

	public static void main(String[] args) throws IOException {
		
		BufferedReader bufferreader=new BufferedReader(new FileReader(new File("record.txt")));
	
		BufferedWriter bufferwriter=new BufferedWriter(new FileWriter(new File("sharma.txt")));
		
		int i=0;
		while((i=bufferreader.read())!=-1) {
			
			bufferwriter.write((char)i);
			
		}
		bufferwriter.close();
		bufferreader.close();
		
		System.out.println("done");
		
		
	}
}
