//import java.util.*;
//
//public class Test5 {
//    
//    private int n, y;
//    private int[] fgl, fgr;
//    private List<Integer> l, r;
//    private Integer[][][] dp;
//    private static final int MOD = 1000000007;
//    
//    // Return index of first ele in list > val
//    private int fg(List<Integer> list, int val, int s, int e) {
//        if (s > e) {
//            return list.size();
//        }
//        int mid = (s + e) / 2;
//        if (list.get(mid) > val) {
//            int x = fg(list, val, s, mid - 1);
//            if (x != list.size()) {
//                return x;
//            }
//            return mid;
//        }
//        return fg(list, val, mid + 1, e);
//    }
//    
//    // dir = 0 is left
//    private int callMe(List<Integer> list, int i, int pos, int dir) {
//        
//        if(pos < 0 || pos > n) {
//            return 0;
//        }
//        if(i == list.size()) {
//            return pos == y ? 1 : 0;
//        }
//        if(dp[i][pos][dir] != null) {
//            return dp[i][pos][dir];
//        }
//        
//        int ans = pos == y ? 1 : 0;
//        
//        // Go some steps left/right
//        for(int c=1; c<=list.size() - i; c++) {
//            ans += callMe(dir == 1 ? r : l, 
//                          dir == 1 ? fgr[i + c - 1] : fgl[i + c - 1], 
//                          dir == 1 ? pos - c : pos + c, 1 - dir);
//            ans = ans % MOD;
//        }
//        return dp[i][pos][dir] = ans;
//    }
//    
//    public int solve(String s, int n, int x, int y) {
//        
//        this.n = n;
//        this.y = y;
//        
//        // Build l & r
//        this.l = new ArrayList<>();
//        this.r = new ArrayList<>();
//        for(int i=0;i<s.length();i++) {
//            if(s.charAt(i) == 'l') {
//                l.add(i);
//            }
//            else {
//                r.add(i);
//            }
//        }
//        
//        this.dp = new Integer[Math.max(l.size(), r.size())][n + 1][2];
//        
//        // Build fgl & fgr
//        this.fgl = new int[r.size()];
//        this.fgr = new int[l.size()];
//        for(int i=0;i<r.size();i++) {
//            fgl[i] = fg(l, r.get(i), 0, l.size() - 1);
//        }
//        for(int i=0;i<l.size();i++) {
//            fgr[i] = fg(r, l.get(i), 0, r.size() - 1);
//        }
//        
//        // Solve
//        return callMe(r, 0, x, 0) + callMe(l, 0, x, 1);
//    }
//    
//    
//    
//    
//    
//    
//    
//    public static void main(String[] args) {
//        System.out.println(new Test5().solve("rrlrlr", 6, 1, 2));
//    }
//}

public class Test5{

static int minTime;

public static String reach(String arr[], int maxTime) {

    int n = arr.length;

    char a[][] = new char[n][];

    for (int i = 0; i < n; i++) {
        a[i] = arr[i].toCharArray();
    }

    for(int i = 0; i < a.length; i++){
    	for(int j = 0; j < a[0].length; j++){
    		System.out.print(a[i][j]);
    	}
    	System.out.println();
    }
    
    minTime = Integer.MAX_VALUE;

    reach(a, maxTime, 0, 0, new boolean[n][n], 0);

    if (minTime <= maxTime) {
        return "YES";
    } else {
        return "NO";
    }

}

public static void reach(char arr[][], int maxTime, int i, int j, boolean visited[][], int time) {

	System.out.println(arr.length);
	System.out.println(arr[0].length);
    if (i < 0 || j < 0 || i >= arr.length || j >= arr[0].length || arr[i][j] == '#' || visited[i][j] == true) {
        return;
    }

    if (i == arr.length - 1 && j == arr[0].length - 1) {
        minTime = Math.min(minTime, time);
        return;
    }

    visited[i][j] = true;

    reach(arr, maxTime, i - 1, j, visited, time + 1);
    reach(arr, maxTime, i, j - 1, visited, time + 1);
    reach(arr, maxTime, i + 1, j, visited, time + 1);
    reach(arr, maxTime, i, j + 1, visited, time + 1);

    visited[i][j] = false;
}

public static void main(String[] args) {

//    Scanner sc = new Scanner(System.in);

    int n = 3;
    		

//    String arr[] = new String[n];
    
    String[] arr={"..##","#.##","#..."};
    

//    for (int i = 0; i < n; i++) {
//        arr[i] = sc.nextLine();
//    }

//    int time = sc.nextInt();
    
    int time=5;

    System.out.println(reach(arr, time));
}
}
