
create table employee09
(
   EmployeeID integer primary key ,
 
   EmployeeName  varchar(30) not null,
 
   EmployeeAddress varchar(30) check(employeeaddress not in('newyork','london','paris')),
 
   Salary integer check(salary BETWEEN 20000 and 30000),

   companyaddress varchar2(20) default 'ASV Suntech Park'

   );
 


insert into employee09 values(1,'yati','banglore',22000,'ecospace');

insert into employee09 values(2,'sam','banglore',25000,'kormangla');



//salary table

Salary Table

EmployeeID  :- should not be duplicate
Employee PF  :- should not be negative
Employee HRA :- should not be negative

create table salary
(
	EmployeeID integer ,
	Employeepf integer constraint nonnegetive check(Employeepf>0),
	Employeehra integer constraint nonnegetive check(Employeehra>0)
	constraint fkkey foreign key(EmployeeID) references Employee09(EmployeeID)
);
