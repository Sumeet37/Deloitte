package CollectionPackage;

import java.util.*;

public class CustomerMainSorting {

	public static void main(String[] args) {
		
		List <Customer> allCustomers=new ArrayList<Customer>();
		Customer c1=new Customer(101,"halsey","pune",65900);
		allCustomers.add(c1);
		
		allCustomers.add(new Customer(102,"snoop","delhi",34000));
		allCustomers.add(new Customer(103,"sean","mumbai",56000));
		allCustomers.add(new Customer(104,"anne","jaipur",23000));
		allCustomers.add(new Customer(105,"marie","bangalore",88000));
		
		
		Iterator<Customer> customerIterator=allCustomers.iterator();
		
		while (customerIterator.hasNext()) {
			Customer temp=customerIterator.next();
			System.out.println(temp.getCustomerId()+" "+temp.getCustomerName()+" "+temp.getCustomerAddress()+" "+temp.getBillAmount()+"\n");
		}
		
		//sorting on bill amount
		System.out.println("after sorting");
		
		Collections.sort(allCustomers);//implement COMPARABLE on customer and ovveride compareTo
		
		System.out.println(allCustomers);
		
		//sorting based on user requirement
		//COMPARATOR class implemented on a class and its objs passed in sort method
		//three sorting ways
				
		Scanner scanner=new Scanner(System.in);
		System.out.println("1 for bill 2 for name 3 for address");
		int choice=scanner.nextInt();
		
		if(choice==1) {
			Collections.sort(allCustomers);
			System.out.println(allCustomers);
		}else if(choice==2){
			Collections.sort(allCustomers,new NameComparator());
			System.out.println(allCustomers);
		}else if(choice==3) {
			Collections.sort(allCustomers,new Comparator<Customer>() {

				@Override
				public int compare(Customer c1, Customer c2) {
					
					if(c1.getCustomerAddress().compareTo(c2.getCustomerAddress()) > 0) {
						return 0;
						
					}
					else {
						return -1;
					}
					
				}
			}
					
					);
			System.out.println(allCustomers);
			
		}
	}
	
	
		
	
	
		
	
}
