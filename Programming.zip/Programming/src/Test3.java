
//INTUIT// find the number

import java.util.*;

public class Test3 {

	

	static String Find_It (int X, long K, String S, int N) {
	    S=" "+S;
	    //int cnt=0;
	    List<TreeSet<Character> >v=new ArrayList<TreeSet<Character> >();
	    for(int i=1;i<=N;i+=X)
	    {
	        //cnt++;
	    	TreeSet<Character>temp=new TreeSet<>();
	        for(int j=i;j<=Math.min(N,X+i-1);j++)
	        {
//	            temp.insert(S[j]);
	        	temp.add(S.charAt(j));
	        }
//	        v.push_back(temp);
	        v.add(temp);
	    }
	    int blocks=v.size();
	    int ind=0;
//	    vector<vector<ll> >value(blocks,vector<ll>(X));
	    long[][] value=new long[blocks][X];
	    //for(int i=0;i<blocks;i++)sort(v.get(i).begin(),v.get(i).end());
	    long val=1;String b="";boolean flag=false;
	    for(int i=blocks-1;i>=0 && !flag;i--)
	    {
//	        Set<Character> :: iterator it;
	        int j=0;
//	        for(it=v.get(i).begin();it!=v.get(i).end() && !flag;it++,j++)//int j=0;j<v.get(i).size();j++)
//	        {
//	            value[i][j]=val*(j+1);
//	            if(value[i][j]>=K)
//	            {
//	                ind=i;
//	                b+=*it;
//	                if(K==value[i][j])K=0;else if(j)K-=value[i][j-1];
//	                flag=1;
//	            }
//	        }
//	        for(it=v.get(i).begin();it!=v.get(i).end() && !flag;it++,j++)//int j=0;j<v.get(i).size();j++)
	        Iterator<Character> it=v.get(i).iterator();
	        
	        for(;it.hasNext() && !flag && j<X;)
	        {
//	        	System.out.println("block "+blocks + " X " +X );
//	        	System.out.println("i "+i + " j " +j );
	            value[i][j]=val*(j+1);
	            if(value[i][j]>=K)
	            {
	                ind=i;
	                
	                b+=it.next();
	                System.out.println("b" + b);
	                if(K==value[i][j])K=0;
//	                else if(j)K-=value[i][j-1];
	                else if(j!=0)K-=value[i][j-1];
	                flag=true;
	            }
	            
	            j++;
	        }
	        if(!flag)val=value[i][v.get(i).size()-1];
	    }
//i 1 j 0i 1 j 1i 1 j 2i 1 j 3i 1 j 4i 0 j 0i 0 j 1
	    
	    String a="",c="";
	    for(int i=0;i<ind;i++){
//	    	a=a+v.get(i).begin();	
	    	a=a+v.get(i).first();	
	    }
	    
	    for(int i=ind+1;i<blocks;i++)
	    {
	    	//cout<<"hello\n";
	    	//if(blocks-1==i)cout<<v.get(i)[v.get(i).size()-1]<<"\n";
	    	if(K==0){
//	    		c+=v.get(i).rbegin();
	    		c+=v.get(i).last();
	    		continue;
	    		}
	    	
	    	//Set<Character> :: iterator it;
	    	int j=0;
	    	 Iterator<Character> it=v.get(i).iterator();
	    	 
//	        for(it=v.get(i).begin();it!=v.get(i).end();it++,j++)//int j=0;j<v.get(i).size();j++)
	    	 for(;it.hasNext();j++)
	    	 {
	            if(value[i][j]>=K)
	            {
	                c+=it.next();
	                if(K==value[i][j])K=0;
	                else if(j!=0)K-=value[i][j-1];
	                break;
	            }
	        }
	    }
	    System.out.println(v);
	    
//	    System.out.println(a +"-" + b +"-" + c );
	    return a+b+c;
	   // Write your code here
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub


	    int N=10;
	    int X=5;
	    long K=10;
	    String S="1234567891";

	    String out_;
	    out_ = Find_It(X, K, S, N);
	
		
		System.out.println("hello");
		System.out.println(out_);
		
	}
	
	
	

}
