package exceptionPackage;

public class CheckedException {

	
	public void display1()throws InterruptedException {
		System.out.println("in display1");
		Thread.sleep(100);
		
	
	}
	
	public void display2()throws Exception {
		System.out.println("in display1");
		Thread.sleep(100);
		
	
	}
	public void display3(){
		System.out.println("in display1");
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
	}
	
	public static void main(String[] args)throws Exception{
		CheckedException ce=new CheckedException();
		ce.display3();
		
		
		ce.display1();
		ce.display2();
		
	}
}
