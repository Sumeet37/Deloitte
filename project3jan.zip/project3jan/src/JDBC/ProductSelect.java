package JDBC;

import java.sql.*;
import java.util.*;

public class ProductSelect {

	public static void main(String[] args) throws SQLException {

		Connection connection=DBConnection.makeConnection();
		Statement statement=connection.createStatement();
		
		String query="select * from hr.product";
		ResultSet res=statement.executeQuery(query);
		
		while(res.next()) {
			System.out.print(res.getInt(1) +" ");
			System.out.print(res.getString(2) +" ");
			System.out.print(res.getInt(3) +" ");
			System.out.println(res.getInt(4) +" ");
		}
		
		statement.close();
		connection.close();
		
		
	}
}
