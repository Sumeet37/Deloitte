package JDBC;

import java.sql.*;

public class Demo1 {

public static void main(String[] args) throws ClassNotFoundException,SQLException {
	//load driver

	Connection connection=DBConnection.makeConnection();
	// get statement
	
	Statement st=connection.createStatement();
	ResultSet res=st.executeQuery("select * from hr.customer");
	
	while(res.next()) {
		System.out.print(res.getInt(1) +" ");
		System.out.print(res.getString(2) +" ");
		System.out.print(res.getString(3) +" ");
		System.out.println(res.getInt(4) +" ");
	}
	
	
	connection.close();
	st.close();
	
}	
	
}
