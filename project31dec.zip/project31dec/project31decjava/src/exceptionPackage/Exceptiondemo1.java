package exceptionPackage;
import java.util.*;


public class Exceptiondemo1 {

	int num1,num2,result;
	Scanner scanner=new Scanner(System.in);
	
	public void divide() {
		try {
			System.out.println("enter num1");
			num1=scanner.nextInt();
			System.out.println("enter num2");
			num2=scanner.nextInt();
			result=num1/num2;
			
			System.out.println(result);
		} catch (InputMismatchException	e) {
			// TODO Auto-generated catch block
			System.out.println(" alphabet entered");
			
		}catch (ArithmeticException e) {
			// TODO Auto-generated catch block
			System.out.println(" divided by 0");
			
		}
		
		System.out.println("divide frunction ended");
		
		
	}
	public static void main(String[] args) {
		System.out.println("main started");
		Exceptiondemo1 d=new Exceptiondemo1();
		
		d.divide();
		System.out.println("main ended");
	}
	
}
