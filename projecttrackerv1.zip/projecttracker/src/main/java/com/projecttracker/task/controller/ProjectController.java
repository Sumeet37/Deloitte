package com.projecttracker.task.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.projecttracker.model.AssignTasks;
import com.projecttracker.model.User;
import com.projecttracker.task.service.impl.AssignTasksServiceImpl;

@Controller
public class ProjectController {
        
	@Autowired
	AssignTasksServiceImpl tasksimpl;
	
	@RequestMapping("login")
	public ModelAndView viewloginpage()
	{
		ModelAndView view=new ModelAndView();
		view.setViewName("login");
		view.addObject("command",new User());
		return view;
	}
	
	@RequestMapping("loginauthentication")
	public ModelAndView loginpage(User user)
	{
		ModelAndView view=new ModelAndView();
		boolean ifExist=tasksimpl.authenticate(user);
		
		if(!ifExist) {
			view.setViewName("error");
			
		}
		else {
			//check lead or user
			boolean Leader_Status= tasksimpl.checkLeaderStatus(user);
			if(Leader_Status) {
				//lead
				User leader=tasksimpl.userInfoById(user.getUserId());
				view.addObject("leader",leader);
				view.setViewName("leader");
				}
			else {
				//user
				User retreiveduser=tasksimpl.userInfoById(user.getUserId());
				view.addObject("user",retreiveduser);
				view.setViewName("user");
			}
		}
		
		return view;
	}
	
	
	
	
	
}
