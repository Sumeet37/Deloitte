package com.shopping.deloitte.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ConfirmProductServlet
 */
public class ConfirmProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ConfirmProductServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String selectedItems[]=request.getParameterValues("item");
		PrintWriter out=response.getWriter();
		
		//getting session
		HttpSession session=request.getSession();
		String currentBuyer=(String) session.getAttribute("CurrentBuyer");
		
		
		if (selectedItems==null) {
			out.println("select a item  "+ currentBuyer);
			out.println("<a href='Item.html>GO BACK</a>");
			
		}else {
			out.println(currentBuyer+" you selected these  items");
			for (String items : selectedItems) {
				out.println("<h1> "+items);
			}
		}
		
		
		
	}

}
