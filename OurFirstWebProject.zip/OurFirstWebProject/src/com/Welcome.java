package com;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Welcome
 */
public class Welcome extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Welcome() {
        super();
    
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
    
    int counter=0;
    
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		counter++;
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		
		response.getWriter().println("<title>Welcome</title>");
		
		response.getWriter().println("<h1> Welcome to my website"+username+"</h1>");
		response.getWriter().println("<h1>password is "+password+"</h1>");
		response.getWriter().println("<h1> you are visiter number:"+counter+"</h1>");
		response.getWriter().println("<a href='Shop.html'>SHOP PAGE</a>");
	}

}
