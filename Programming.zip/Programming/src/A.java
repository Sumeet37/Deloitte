import java.util.PriorityQueue;
import java.util.regex.MatchResult;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class B {

}

class C extends B {

}

class D extends C {

}

interface base1 {

}

interface base2 {

}

class X implements base1, base2 {

}

public class A {

	// static void display(D d){
	// System.out.println("D");
	// }

	static void display(B b) {
		System.out.println("B");
	}

	static void display(Object o) {
		System.out.println("O");
	}

	static void display(C c) {
		System.out.println("C");
	}

	static void test(String s) {
		System.out.println("String");
	}
	//
	// static void test(Integer i){
	// System.out.println("I");
	// }

	static void test(Object o) {
		System.out.println("Onbj");
	}

	static void test(int ii) {
		System.out.println("int");
	}

	static void intf(base1 b1) {
		System.out.println("base1");
	}

	static void intf(base2 b2) {
		System.out.println("base2");
	}

	static void intf(X x) {
		System.out.println("X");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer number = 10;
		number++;
		assert number == null && number < 0;
		System.out.println(number);

		Object o = null;
		display(o);

		Integer i = null;
		// int tt=3;
		// seee the difference
		test(null);
		test(i);

		// intf(new X());
		System.out.println("regex");
		// Pattern p = Pattern.compile("^([a-zA-Z]+)([0-9]+)(.*)");
		//Pattern p = Pattern.compile("ab[a-z]{1}de");
		//Matcher m = p.matcher("abxabcdefgabdde");

		//String s="xabxdeyyabcdey";
		String s="juliasamanthantjulia";
		String x="ant";//"ab*de";
		
		if(x.contains("*")){
			System.out.println("true");
			x=x.replaceAll("\\*", "[a-z]{1}");
		}
		
		System.out.println(x);
		
		Pattern p = Pattern.compile(x);
		Matcher m = p.matcher(s);
		
		if(m.find()){
			String matchingString=m.group(0);
			System.out.println(matchingString + " "+s.indexOf(matchingString));
			
		}else{
			System.out.println("not present");
		}
		
		
		// if an occurrence if a pattern was found in a given string...
//		while(m.find()) {
//			// ...then you can use group() methods.
//			System.out.println(m.group()); // whole matched expression
//			//System.out.println(m.group(1));
//			// System.out.println(m.group(1)); // first expression from round
//			// // brackets (Testing)
//			// System.out.println(m.group(2)); // second one (123)
//			// System.out.println(m.group(3)); // third one (Testing)
//		}

//		MatchResult result = m.toMatchResult();
//		System.out.println("Current Matcher: " + result);
//
//		while (m.find()) {
//			// Get the group matched using group() method
//			System.out.println(matcher.group());
//		}
		
		System.out.println("test");
		
		String l ="";
		
		Long.valueOf(l);
//		System.out.println(ll);
		
		
//		int arr[]={2,3,5,1,1,2,1};
		int arr[]={10,10,10};
//		int arr[]={5,10,10};
		
		
		System.out.println("opytimal");
		System.out.println(optimalColors(arr,5));
		
		
		System.out.println("opt1");
		System.out.println(opt2(arr,7));
		
		
		PriorityQueue<String> pp=new PriorityQueue<String>();
		
		pp.add("carrot");
		pp.add("apple");
		pp.add("ban");
		
		System.out.println(pp.poll());
		System.out.println(pp.peek());
		
		
	}
	
	private static int opt2(int[] a, int m) {

		int n = a.length;
		int count = 0;
		for (int i = 0; i < n; i++) {
			int total = 0;
			for (int j = i; j < n; j++) {
				total += a[i];
				if (total <= m) {
					count = Math.max(count, ((j - i) + 1));
				}
			}
		}
		return count;
	
	}

	public static  int optimalColors(int[] a, int m) {
        int max = 0;
        int left =0;
        int right = 0;
        while (right < a.length) {
            int temp = left;
            int total = 0;
            while (temp < right) { //we add up the prices from left (replaced by temp) to right index to see what the current total is
                total += a[temp];
                if (temp+1 == right) {
                    total+=a[right];
                    break;
                }
                temp++;
            }
            if (total <= m) { // if the total falls within budget, we set the max # of indexes shown by right-left+1
                max = Math.max(max, right-left+1);
            }

            if (total >m) { // if we exceeded budget, left moves up 1
                left++;

            } else { // if we haven't exceeded budget, we try one more index
                right++;
            }
        }

        return max;
    }

}
