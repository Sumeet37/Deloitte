
public class Bye {
	public void sayBye() {
		System.out.println("bye");
	}
}
