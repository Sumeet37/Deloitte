import java.util.*;
public class Solution {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
////		String str="TacoCat";
//		String str="CATattac";
//		Solution s=new Solution();
//		System.out.println(s.solution(str));

		matrixDiagonalPrinting();
		
		
		
	}
	
	
	private static void matrixDiagonalPrinting() {
		// TODO Auto-generated method stub
		System.out.println("matrix");
		
		int a[][] = {
	            { 1, 2, 3, 4 },     
	            { 5, 6, 7, 8 },
	            { 9, 10, 11, 12 },  
	            { 13, 14, 15, 16 },
	            { 17, 18, 19, 20 },
	        };
		
		int n=5,m=4;
		int i=0,j=0;
		int temp,temp1;
		System.out.println("");
		
//1 5 2 9 6 3 13 10 7 4 17 14 11 8 18 15 12 19 16 20 
//1 5 2 9 6 3 13 10 7 4 17 14 11 8 18 15 12 19 16		
//		while(!(i==n-1 && j==m-1)){
		while(i<n && j<m){
			temp=i;
			temp1=j;
			
			while(i>=0 && j<m){
				System.out.print(a[i][j] + " ");
				i--;
				j++;
			}
//			System.out.println(temp);
//			System.out.println(temp1);
			
			if(temp<n-1){
				i=temp+1;
				j=0;
//				System.out.println("temp= "+temp);
//				System.out.println("temp1= "+temp1);
			}else{
				
				i=n-1;
				j=temp1+1;
			}
			
		}
		
	}


	boolean checkBalanced(int lower[], int upper[]) {

		for (int i = 0; i < 26; i++) {
			if (lower[i] != 0 && (upper[i] == 0))
				return false;

			else if ((lower[i] == 0) && (upper[i] != 0))
				return false;
		}
		return true;
	}
	
	public int solution(String S) {

		int[] lower = new int[26];
		int[] upper = new int[26];

		Arrays.fill(lower, 0);
		Arrays.fill(upper, 0);

		for (int i = 0; i < S.length(); i++) {
			if (S.charAt(i) >= 65 && S.charAt(i) <= 90)
				upper[S.charAt(i) - 'A']++;
			else
				lower[S.charAt(i) - 'a']++;
		}

		Map<Character, Integer> hm = new HashMap<Character, Integer>();

		for (int i = 0; i < 26; i++) {
			if (lower[i] != 0 && upper[i] == 0)
				hm.put((char) (i + 'a'), 1);
			else if (upper[i] != 0 && lower[i] == 0)
				hm.put((char) (i + 'A'), 1);
		}

		Arrays.fill(lower, 0);
		Arrays.fill(upper, 0);

		int i = 0, currEnd = 0;

		int start = -1, end = -1;

		int minlen = Integer.MAX_VALUE;

		while (i < S.length()) {
			if (hm.get(S.charAt(i)) != null) {

				while (currEnd < i) {
					if (S.charAt(currEnd) >= 65 && S.charAt(currEnd) <= 90)
						upper[S.charAt(currEnd) - 'A']--;
					else
						lower[S.charAt(currEnd) - 'a']--;

					currEnd++;
				}
				i += 1;
				currEnd = i;
			} else {
				if (S.charAt(i) >= 65 && S.charAt(i) <= 90)
					upper[S.charAt(i) - 'A']++;
				else
					lower[S.charAt(i) - 'a']++;

				while (true) {
					if (S.charAt(currEnd) >= 65 && S.charAt(currEnd) <= 90 && upper[S.charAt(currEnd) - 'A'] > 1) {
						upper[S.charAt(currEnd) - 'A']--;
						currEnd++;
					} else if (S.charAt(currEnd) >= 97 && S.charAt(currEnd) <= 122 && lower[S.charAt(currEnd) - 'a'] > 1) {
						lower[S.charAt(currEnd) - 'a']--;
						currEnd++;
					} else
						break;
				}

				if (checkBalanced(lower, upper)) {
					if (minlen > (i - currEnd + 1)) {
						minlen = i - currEnd + 1;
						start = currEnd;
						end = i;
					}
				}
				i =i+ 1;
			}
		}

		if (start == -1 || end == -1)
			return -1;

		else {
			String strr = "";
			for (int j = start; j <= end; j++)
				strr += S.charAt(j);

			 System.out.println(strr);
			return strr.length();
		}
	}
}
