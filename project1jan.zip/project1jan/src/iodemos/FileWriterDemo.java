package iodemos;

import java.io.FileWriter;
import java.io.IOException;

public class FileWriterDemo {

	public static void main(String[] args) throws IOException {
		FileWriter fw=new FileWriter("record.txt");
		fw.write("my name is record");
		
		fw.close(); //no output till closed
		System.out.println("done");
		
	}
}
