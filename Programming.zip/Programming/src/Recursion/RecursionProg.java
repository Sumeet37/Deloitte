package Recursion;

import java.util.*;

public class RecursionProg {

	public static void main(String[] args) {

		
		System.out.println(recurNoOfPath(2-1,2-1));
		
		
		
		 find_permutation();
		 
		 System.out.println("String reverse");
		 StringReverse("abc",0);
		
		
	}

	

	private static void StringReverse(String s, int i) {
		
		if(i>=s.length()){
			return;
		}
		
		StringReverse(s,i+1);
		System.out.print(s.charAt(i));
		
	}



	private static void find_permutation() {
		
		System.out.println("permute");
		String S="ABC";
		
		List<String> sol=new ArrayList<>();
		
		permutation(sol,new StringBuffer(S),new String(""),S.length());
		
		System.out.println(sol);
		
	}

	private static void permutation(List<String> sol,StringBuffer str,String ans,int size) {
		
		if (str.length() < 1) {
			sol.add(ans);
		}
		
		for(int i=0;i<str.length();i++){
			char c=str.charAt(i);
			//ans.add(c);
			ans=ans+c;
			str.deleteCharAt(i);
			permutation(sol,str,new String(ans),size--);
			str.insert(i, c);
			//ans.remove(ans.size()-1);
			ans=ans.substring(0, ans.length()-1);
			
		}
		
	}

	static long recurNoOfPath(int m,int n ){
        if(m==0 && n==0){
           return 1L; 
        }
        if(m<0 || n<0){
            return 0L;
        }
        //right
        return recurNoOfPath(m,n-1) + recurNoOfPath(m-1,n);
    }
}
