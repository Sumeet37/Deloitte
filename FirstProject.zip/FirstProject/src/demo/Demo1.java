//local and instance variables
package demo;
public class Demo1 {
int i;
int num=10;
int num2=i;
public void disp() {
	int j=20;//bound to be intitilised
	if (num==10) {
		j=20;
	}
	System.out.println((i+num)-j); 
}
public static void main(String[] args) {
	Demo1 d=new Demo1();
	d.disp();
	
}

}
