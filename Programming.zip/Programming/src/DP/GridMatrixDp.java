package DP;

import java.util.*;

public class GridMatrixDp {

	private static int min(int x, int y, int z) {
		if (x < y)
			return (x < z) ? x : z;
		else
			return (y < z) ? y : z;
	}

	private static int minCost(int cost[][], int m, int n) {
		int i, j;
		int tc[][] = new int[m + 1][n + 1];

		tc[0][0] = cost[0][0];

		/* Initialize first column of total cost(tc) array */
		for (i = 1; i <= m; i++)
			tc[i][0] = tc[i - 1][0] + cost[i][0];

		/* Initialize first row of tc array */
		for (j = 1; j <= n; j++)
			tc[0][j] = tc[0][j - 1] + cost[0][j];

		/* Construct rest of the tc array */
		for (i = 1; i <= m; i++)
			for (j = 1; j <= n; j++)
				tc[i][j] = min(tc[i - 1][j - 1], tc[i - 1][j], tc[i][j - 1]) + cost[i][j];

		for (i = 0; i <= m; i++) {
			for (j = 0; j <= n; j++) {
				System.out.print(tc[i][j] + " ");
			}
			System.out.println();
		}
		return tc[m][n];
	}

	static int getMaxGold(int gold[][], int m, int n) {

		// Create a table for storing
		// intermediate results and initialize
		// all cells to 0. The first row of
		// goldMineTable gives the maximum
		// gold that the miner can collect
		// when starts that row
		int goldTable[][] = new int[m][n];

		for (int[] rows : goldTable)
			Arrays.fill(rows, 0);

		
		
		for (int col = n - 1; col >= 0; col--) {
			for (int row = 0; row < m; row++) {

				// Gold collected on going to
				// the cell on the right(->)
				int right = (col == n - 1) ? 0 : goldTable[row][col + 1];

				// Gold collected on going to
				// the cell to right up (/)
				int right_up = (row == 0 || col == n - 1) ? 0 : goldTable[row - 1][col + 1];

				// Gold collected on going to
				// the cell to right down (\)
				int right_down = (row == m - 1 || col == n - 1) ? 0 : goldTable[row + 1][col + 1];

				// Max gold collected from taking
				// either of the above 3 paths
				goldTable[row][col] = gold[row][col] + Math.max(right, Math.max(right_up, right_down));

			}
		}

		// The max amount of gold collected will be
		// the max value in first column of all rows
		int res = goldTable[0][0];

		for (int i = 1; i < m; i++)
			res = Math.max(res, goldTable[i][0]);

		return res;
	}

	static int MYSOLgetMaxGold(int gold[][], int m, int n) {

		// Create a table for storing
		// intermediate results and initialize
		// all cells to 0. The first row of
		// goldMineTable gives the maximum
		// gold that the miner can collect
		// when starts that row
		int goldTable[][] = new int[m][n];

		for (int[] rows : goldTable)
			Arrays.fill(rows, 0);

		//last col
		for(int i=0;i<m;i++){
			goldTable[i][n-1]=gold[i][n-1];
		}
		
	
		
		for (int col = n - 1; col >= 0; col--) {
			for (int row = 0; row < m; row++) {

				// Gold collected on going to
				// the cell on the right(->)
				int right = (col == n - 1) ? 0 : goldTable[row][col + 1];

				// Gold collected on going to
				// the cell to right up (/)
				int right_up = (row == 0 || col == n - 1) ? 0 : goldTable[row - 1][col + 1];

				// Gold collected on going to
				// the cell to right down (\)
				int right_down = (row == m - 1 || col == n - 1) ? 0 : goldTable[row + 1][col + 1];

				// Max gold collected from taking
				// either of the above 3 paths
				goldTable[row][col] = gold[row][col] + Math.max(right, Math.max(right_up, right_down));

			}
		}

		// The max amount of gold collected will be
		// the max value in first column of all rows
		int res = goldTable[0][0];

		for (int i = 1; i < m; i++)
			res = Math.max(res, goldTable[i][0]);

		return res;
	}

	
	public static void main(String[] args) {

		int cost[][] = { { 1, 2, 3 }, { 4, 8, 2 }, { 1, 5, 3 } };

		// Min Cost Path in GRID

		System.out.println(minCost(cost, 2, 2));
		
		//max gold from 1st column

		int gold[][] = { { 1, 3, 1, 5 }, { 2, 2, 4, 1 }, { 5, 0, 2, 3 }, { 0, 6, 1, 2 } };

		int m = 4, n = 4;

		System.out.print(getMaxGold(gold, m, n));
		System.out.print(MYSOLgetMaxGold(gold, m, n));

	}

}
