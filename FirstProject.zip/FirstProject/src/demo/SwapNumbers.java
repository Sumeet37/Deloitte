package demo;
import java.util.*;
public class SwapNumbers {

	public static void swap(int num1,int num2) {
		num1=num1+num2;
		num2=num1-num2;
		num1=num1-num2;
		System.out.println("a is"+num1+"b is "+num2);
	}
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int num1=scanner.nextInt();
		int num2=scanner.nextInt();
		System.out.println("a is"+num1+"b is "+num2);
		swap(num1,num2);
		
		
		
	}
}
