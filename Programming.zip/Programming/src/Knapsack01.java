import java.util.*;

public class Knapsack01 {

	public static void main(String[] args) {
		

		
		List<String> SAMLRoles = new ArrayList<>();
		
			
			String[] assertionRoles = {"LaMEDS-SIT_WP-LTCSupervisor","  _LA-DWH-BA-User-SIT-EA","  _LA-DWH-BA-Default-EA","  IE-SIT_WP-Manager","  _LA-DWH-BA-SIT-AP-IE-SNTA","  _LA-DWH-BA-SIT-AP-WM-IE-SNTA","  _LA-DWH-BA-SIT-AP-Audit-IE-SNTA","  _LA-DWH-BA-SIT-AP-App-IE-SNTA","  _LA-DWH-BA-SIT-AP-Redet-IE-SNTA","  _LA-DWH-BA-SIT-AP-CR-IE-SNTA","  _LA-DWH-BA-SIT-AP-OD-IE-SNTA","  _LA-DWH-BA-SIT-AP-EBT-IE-SNTA","  _LA-DWH-BA-SIT-C-IE-SNTA","  _LA-DWH-BA-SIT-DSNAP-IE-SNTA","  _LA-DWH-BA-SIT-DSNAP-ER-IE-SNTA","  _LA-DWH-BA-SIT-EBT-IE-SNTA","  _LA-DWH-BA-SIT-FITAP-IE-SNTA","  _LA-DWH-BA-SIT-FITAP-OD-IE-SNTA","  _LA-DWH-BA-SIT-Fraud-IE-SNTA","  _LA-DWH-BA-SIT-KCSP-IE-SNTA","  _LA-DWH-BA-SIT-LaCAP-IE-SNTA","  _LA-DWH-BA-SIT-Mgmt-IE-SNTA","  _LA-DWH-BA-SIT-Mgmt-SOR-IE-SNTA","  _LA-DWH-BA-SIT-MC-IE-SNTA","  _LA-DWH-BA-SIT-MC-OD-IE-SNTA","  _LA-DWH-BA-SIT-QC-IE-SNTA","  _LA-DWH-BA-SIT-QC-Active-IE-SNTA","  _LA-DWH-BA-SIT-QC-Negative-IE-SNTA","  _LA-DWH-BA-SIT-SNAP-IE-SNTA","  _LA-DWH-BA-SIT-SNAP-WM-IE-SNTA","  _LA-DWH-BA-SIT-SNAP-ABAWD-IE-SNTA","  _LA-DWH-BA-SIT-SNAP-Audit-IE-SNTA","  _LA-DWH-BA-SIT-SNAP-RS-IE-SNTA","  _LA-DWH-BA-SIT-SNAP-LaJET-IE-SNTA","  _LA-DWH-BA-SIT-SNAP-SR-IE-SNTA","  _LA-DWH-BA-SIT-SNAP-MWR-IE-SNTA","  _LA-DWH-BA-SIT-SNAP-OD-IE-SNTA","  _LA-DWH-BA-SIT-SNAP-Sanction-IE-SNTA","  _LA-DWH-BA-SIT-SNAP-LaCap-IE-SNTA","  _LA-DWH-BA-SIT-Stat-IE-SNTA","  _LA-DWH-BA-SIT-Stat-FITAP-IE-SNTA","  _LA-DWH-BA-SIT-Stat-LaCAP-IE-SNTA","  _LA-DWH-BA-SIT-Stat-SNAP-IE-SNTA","  _LA-DWH-BA-SIT-Stat-STEP-IE-SNTA","  _LA-DWH-BA-SIT-Stat-OD-IE-SNTA","  _LA-DWH-BA-SIT-STEP-IE-SNTA","  _LA-DWH-BA-SIT-STEP-Fiscal-IE-SNTA","  _LA-DWH-BA-SIT-TANF-IE-SNTA","  _LA-DWH-BA-SIT-TANF-OD-IE-SNTA"};
			
			String samlRolePrefix="IE";
			String samlRoleEnvPrefix="SIT_WP";
			String samlRoleConcat = (samlRolePrefix + "-").concat(samlRoleEnvPrefix + "-");
			System.out.println("TokenProvider : assertionRoles -->"+Arrays.toString(assertionRoles));

			for (String appRole : assertionRoles) {

				/*
				 * String[] trimmedAppRoles = appRole.split("-"); if (trimmedAppRoles.length ==
				 * 3) { if (samlRolePrefix.equalsIgnoreCase(trimmedAppRoles[0].trim()) &&
				 * samlRoleEnvPrefix.equalsIgnoreCase(trimmedAppRoles[1].trim())) {
				 * SAMLRoles.add(trimmedAppRoles[2]); } }
				 */

				// IESDLCP-94238 - AD role changes for WP users
				if (appRole.trim().toLowerCase().startsWith(samlRoleConcat.toLowerCase())) {
					String[] role = appRole.split("-");
					if (null != role && role.length > 0) {
						String roleName = role[role.length - 1];
						if (null != roleName && !roleName.isEmpty())
							SAMLRoles.add(roleName);
							System.out.println(roleName+" true");
					}
				}
			}
		

			System.out.println("hello"+SAMLRoles);
	
		/*
		Scanner sc=new Scanner(System.in);
		System.out.println("no of weghts/values");
		int n=sc.nextInt();
		System.out.println("Weight");
		int W=sc.nextInt();
		System.out.println("value array..");
		int val[]=new int[n];
		for(int i=0;i<n;i++){
			val[i]=sc.nextInt();
		}
		int wt[]=new int[n];
		System.out.println("weight array..");
		for(int i=0;i<n;i++){
			wt[i]=sc.nextInt();
		}
		
		Integer wtI[]=new Integer[n];
		Integer valI[]=new Integer[n];
		
		for(int i=0;i<n;i++){
			wtI[i]=wt[i];
			valI[i]=val[i];
		}
		
		List<Integer> weightsList=Arrays.asList(wtI);
		List<Integer> valsList=Arrays.asList(valI);
		
		
		
		
		
		HashMap<Integer,Integer> memo=new HashMap<Integer,Integer>();
//		bruteForce(W,weightsList,valsList,memo);
	*/
	}

	private static int bruteForce(int target, List<Integer> weights, List<Integer> vals,HashMap<Integer,Integer> memo) {
		
		if(memo.containsKey(target))return memo.get(target);
		if(target<0)return -1;
		
		int maximumValue=0;
		for(int i=0;i<weights.size();i++){
			
			int edge=weights.get(i);
			int edgeValue=vals.get(i);
			int nextNode=target-edge;
			
			List<Integer> tempWeight=new ArrayList<Integer>(weights);
			tempWeight.remove(i);
			List<Integer> tempVals=new ArrayList<Integer>(vals);
			tempVals.remove(i);
			
			int result=bruteForce(nextNode,tempWeight,tempVals,memo);
			if(result!=-1){
				result+=edgeValue;
				
				if(maximumValue<result){
					maximumValue=result;
				}
			}
			
			
		}
		memo.put(target, maximumValue);
		return maximumValue;
	}

}


