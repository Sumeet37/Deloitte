create table emp
(
	emp_no integer primary key,
	empname varchar2(20) not null,
	salary integer,
	designation varchar2(20),
	dept_no integer

)

create table dept
(
	dept_no integer primary key,
	dept_name varchar2(20),
	location varchar2(20) not null

)

select * from emp;
select * from dept;

insert into emp values(12,'yati',98000,'developer',100);   //inconsistent data
insert into dept values(100,'hr','mumbai');


//so use dept_no as foreign key in emp table

alter table emp add constraint fkempdept foreign key(dept_no) references dept(dept_no);



insert into dept values(100,'hr','mumbai');
insert into emp values(12,'yati',98000,'developer',100);



---------------------------------------------------------------------------------

same order and product

order contain product_id as foreign key

product-parent table
order child table


create table order1
(
	order_id integer primary key,
	order_date date,
	product_id integer

);




create table product
(
	product_id integer primary key,
	productName varchar2(20),
	price integer,
	qoh integer not null                                 

)

//qoh is quantity


alter table order1 add constraint fkorderproduct foreign key(product_id) references product(product_id);

insert into product values(101,'recliner',56000,1);
insert into order1 values(1,'12-27-2019',101);

--------------------------------------------------------------------------------

// cascade delete

 CREATE TABLE SECTION (
SECTION_ID INTEGER CONSTRAINT S_ID CHECK (SECTION_ID > 0),
SECTION_NAME CHAR(30) CONSTRAINT S_NAME NOT NULL,
BOOK_COUNT INTEGER,
CONSTRAINT SECT_PRIME PRIMARY KEY (SECTION_ID))


//child 
 
 
CREATE TABLE BOOK
(
ISBN INTEGER CONSTRAINT B_ISBN CHECK (ISBN BETWEEN 1 AND 2000),
TITLE VARCHAR2(200) CONSTRAINT B_TITLE NOT NULL,
AUTHOR VARCHAR2(50) CONSTRAINT B_AUTH NOT NULL,
LENT_DATE DATE,
RETURNED_DATE DATE,
TIMES_LENT NUMBER(6),
SECTION_ID NUMBER(3),
CONSTRAINT BOOK_PRIME PRIMARY KEY (ISBN),
CONSTRAINT BOOK_SECT FOREIGN KEY (SECTION_ID) REFERENCES SECTION(SECTION_ID)
ON DELETE CASCADE)
 
 
-------

INSERT INTO SECTION values(1,'ABC',78);
INSERT INTO SECTION values(2,'XYZ',65);
 
insert into BOOK values(1,'java','james',to_date('3/3/09','mm/dd/yy'),to_date('3/4/09','mm/dd/yy'),10,1);

insert into BOOK values(2,'c','hames',to_date('3/3/09','mm/dd/yy'),to_date('3/4/09','mm/dd/yy'),100,1);


delete from section where section_id=1;

select * from books;


--------------------------------------------------------------------------------

disable constriant and see constraints

------------------------------------------------------------------

JOIN

create table Suppliers
(
   supplier_id varchar(20),
   supplier_name varchar(20)
)
/

create table Orders
(
  order_id varchar(20),
  supplier_id varchar(20),
  order_date date
)


insert into Suppliers values('10000','IBM')
insert into Suppliers values('10001','Hewlett Packard')
insert into Suppliers values('10002','Microsoft')
insert into Suppliers values('10003','TCS')

insert into Orders values('1','10000',to_date('3/3/09','mm/dd/yy'))
insert into Orders values('2','10000',to_date('7/5/10','mm/dd/yy'))
insert into Orders values('3','10001',to_date('12/8/10','mm/dd/yy'))
insert into Orders values('4','20001',to_date('12/8/10','mm/dd/yy'))

select * from suppliers;
select * from orders;



------------------------------------------------------------------

EQUI JOIN


//without using table name or alias

SELECT supplier_name,order_date
FROM suppliers,orders
WHERE suppliers.supplier_id=orders.supplier_id;


//using table name for same coloumn name
 or error 

SELECT suppliers.supplier_id,supplier_name,order_date
FROM suppliers,orders
WHERE suppliers.supplier_id=orders.supplier_id;

//using alias

SELECT s.supplier_id,s.supplier_name,o.order_date
FROM suppliers s,orders o
WHERE s.supplier_id=o.supplier_id;

// using alias means we cannot use table name

//error

SELECT suppliers.supplier_id,s.supplier_name,o.order_date
FROM suppliers s,orders o
WHERE s.supplier_id=o.supplier_id;

//error

SELECT s.supplier_id,s.supplier_name,o.order_date
FROM suppliers s,orders o
WHERE suppliers.supplier_id=orders.supplier_id;



------------------------------------------------------------

left outer JOIN

SELECT s.supplier_id,s.supplier_name,o.order_date
FROM suppliers s,orders o
WHERE s.supplier_id=o.supplier_id(+);


-------------------------------------------------------------

right outer JOIN

SELECT s.supplier_id,s.supplier_name,o.order_date
FROM suppliers s,orders o
WHERE s.supplier_id(+)=o.supplier_id;


-------------------------------------------------------------

full outer JOIN

SELECT s.supplier_id,s.supplier_name,o.supplier_id,o.order_date
FROM suppliers s full outer join orders o
ON s.supplier_id(+)=o.supplier_id;


------------------------------------------------------------------


self join


select e1.last_name || 'works for' || e2.last_name
as "Employee and their managers "
from employees e1,employees e2
WHERE e1.manager_id=e2.manager_id and e1.first_name='Neena';


-------------------------------------------------------------

//run in batch

-------------------------------------------------------------
//SUBQUERY

//2 line code
select roll from fees where amount=10800;
select name from stu where roll=2;

//subquery

select name from stu where roll=(select roll from fees where amount=10800);


UPDATE fees SET amount=10800 where roll=1;

//eror coz 2 values returned

select name from stu where roll=(select roll from fees where amount=10800);


//use in

SELECT name FROM stu WHERE roll IN (select roll from fees where amount=10800);

//exists 
//any
//all



---------------------------------------------------

select amount from fees where roll=(select roll from stu where name='Sai');


--------------------------------------------------

//corelated query

//update

update emp100 a
SET a.sal=(select avg(sal) from emp100 b where a.deptno=b.deptno)
where sal<(select avg(sal) from emp100 c where a.deptno=c.deptno);

select * from emp100;

//delete


delete from emp100 a
where sal = (select max(sal) from emp100 b where a.deptno=b.deptno);


select * from emp100;


/////////////////////////////////////////////////////


insert into emp100 values(1,'Tufail',980000,1);

insert into emp100 values(1,'Tufail',980000,1);
commit;

select * from emp100;
rollback;


select * from emp100;



----------------------------------------------------------------------------


create table citizen
(
CID integer primary key,
CitizenDOB date constraint dobconstraint check(CitizenDOB < '12-27-2019'),
CitizenDOD date constraint deathconstraint check(CitizenDOD < '12-27-2019')

)





------------------------------------------

create table employee00
(
   EmployeeID integer primary key ,
 
   EmployeeName  varchar(30) not null,
 
   EmployeeAddress varchar(30) not null ,
 
   DOB Date not null ,
 
   DOJ Date not null,
 
   Salary integer
   );
 
 
insert into employee00 values(1,'yati','banglore','10-22-1996','12-09-2018',35000)
insert into employee00 values(2,'damini','pune','11-02-1995','10-03-2015',35000)
insert into employee00 values(3,'chetna','pune','08-20-1996','09-23-2019',41000)
insert into employee00 values(4,'ronak','pune','10-20-1996','10-11-2018',65000)
insert into employee00 values(5,'mohan','jaipur','05-20-1996','08-26-2019',25000)




 
 

select * from Employee00;
 
 
select employeename from employee00 where salary >20000;
 
 
select employeename from employee00 where employeeaddress like '%a' or employeeaddress like '%p' or employeeaddress like '%r'
 
update employee00 set salary=salary*1.2;

delete from employee00 where salary<5000;

alter table Employee00 add email varchar2(20);

update employee00 set email='1@gmail.com' where EmployeeID=1;



----------------------------------------------------------------------------

Assignment 2



create table employee09
(
   EmployeeID integer primary key ,
 
   EmployeeName  varchar(30) not null,
 
   EmployeeAddress varchar(30) check(employeeaddress not in('newyork','london','paris')),
 
   Salary integer check(salary BETWEEN 20000 and 30000),

   companyaddress varchar2(20) default 'ASV Suntech Park'

   );
 


insert into employee09 values(1,'yati','banglore',22000,'ecospace');

insert into employee09 values(2,'sam','banglore',25000,'kormangla');



//salary table

Salary Table

EmployeeID  :- should not be duplicate
Employee PF  :- should not be negative
Employee HRA :- should not be negative

create table salary
(
	EmployeeID integer ,
	Employeepf integer constraint nonnegetive check(Employeepf>0),
	Employeehra integer constraint nonnegetive check(Employeehra>0)
	constraint fkkey foreign key(EmployeeID) references Employee09(EmployeeID)
);


CONSTRAINT BOOK_SECT FOREIGN KEY (SECTION_ID) REFERENCES SECTION(SECTION_ID)


