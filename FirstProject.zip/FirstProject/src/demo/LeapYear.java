package demo;
import java.util.*;
public class LeapYear {
	public static  void check(int year) {
		if(year%400==0 ||(year%4==0 && year%100!=0)) {
			System.out.println("leap year");
		}else {
			System.out.println("not a leap year");
		}
	}
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int year=scanner.nextInt();
		check(year);
	}
}
