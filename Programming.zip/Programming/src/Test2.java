
public class Test2 {

	public static void main(String[] args) {

		System.out.println("hello");
		int k=3;
		int n=8;
		int a[]={1,0,0,1,1,1,1,1,1};
		 
		System.out.println(minStops(a,k,n));
	}
	
	static int minStops(int[] airports, int k, int n) { // # sliding window O(N)
		// # assuming flight from the first airport to the last.
		int res = 0;
		int i = 0;
		int j = 0;
		while (i < n - k) {
			j = i + k; // # open the window greedily widest k from i to j;
			while (j > i && airports[j] != 1) { // # shrink the window if not an
												// airport.
				j -= 1;
			}
			if (j == i) { // # exit if airport not found.
				return -1;
			}

			res += 1; // # increment stops if found;
			i = j;
		}
		// # shift to next window.
		return res;
	}

}
