package com.dec24.blocks;

public class W {
public W() {
	System.out.println("in w");
}
}
