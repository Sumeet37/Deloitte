package JDBC;

import java.sql.*;
import java.util.*;


public class AssignmentInsertion {

	public static void main(String[] args) throws SQLException {
		
		Customer customer=new Customer();

		customer.updateCustomer();		
		
		Connection connection=DBConnection.makeConnection();
		String query="update hr.customer set CUSTOMERNAME=?,CUSTOMERADDRESS=?,BILLAMOUNT=?where CUSTOMERID=?";
		PreparedStatement statement=connection.prepareStatement(query);
		
		
		statement.setString(1,customer.getCustomerName());
		statement.setString(2,customer.getCustomerAddress());
		statement.setInt(3,customer.getBillAmount());
		statement.setInt(4,customer.getCustomerId());
		

		statement.executeUpdate();
		
		System.out.println(customer.getCustomerName()+" , your record saved sucessfully!!");
		
	}
}
