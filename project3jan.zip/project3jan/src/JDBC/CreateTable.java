package JDBC;

import java.sql.*;

public class CreateTable {

	public static void main(String[] args) throws SQLException {
		Connection connection=DBConnection.makeConnection();
		Statement statement=connection.createStatement();
		
		String query="create table hr.salary(salary integer,bonus integer)";
		String query1="drop table hr.salary";
		statement.execute(query);
		
		System.out.println("table created");
		statement.close();
		connection.close();
		
		
		
		
	}
	
}
