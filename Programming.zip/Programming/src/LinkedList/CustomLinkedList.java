package LinkedList;

class Node{
		int data;
		Node next;
		Node(int data){
			this.data=data;
			this.next=null;
			
		}
	}

public class CustomLinkedList {

	static Node head;
	
	void printList(Node node)
    {
        while (node != null) {
            System.out.print(node.data + " -> ");
            node = node.next;
        }
    }
	
	public static void main(String[] args) {
		
		CustomLinkedList list = new CustomLinkedList();
        list.head = new Node(85);
        list.head.next = new Node(15);
        list.head.next.next = new Node(4);
        list.head.next.next.next = new Node(20);
        
        System.out.println("Given Linked list");
        list.printList(head);
        head = list.reverse(head);
        System.out.println("Reversed linked list ");
        list.printList(head);
        
  
		
	}

	private Node reverse(Node head2) {
		
		if(head2.next==null){
			return head2;
		}else if(head2.next.next==null){
			Node frwd=head2.next;
			head2.next=null;
			frwd.next=head2;
			return frwd;
		}else{
			//size>=3
			Node prev=head2;
			Node curr=head2.next;
			Node frwd=curr.next;
			prev.next=null;
			
			while(frwd!=null){
				curr.next=prev;
				prev=curr;
				curr=frwd;
				frwd=frwd.next;
				
			}
			curr.next=prev;
			return curr;
		}
		
	}
}
