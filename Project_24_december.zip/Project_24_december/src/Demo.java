
public class Demo {

	int num1=100;
	static int num2=200;
	public void name() {
		num2=10;
	}
	
}         
 