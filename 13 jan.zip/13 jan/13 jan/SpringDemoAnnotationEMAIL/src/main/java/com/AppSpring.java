package com;



import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;



import com.config.AppConfig;

public class AppSpring 
{
    public static void main( String[] args )
    {
        
//    	Resource resource=new ClassPathResource("beans.xml");
    	ApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
    	Email email=context.getBean(Email.class);
    	
    	
    	To to=context.getBean(To.class);
    	
    	to.setToEmail("a@b");
    	to.setToName("tomail");

    	
    	
    	From from=context.getBean(From.class);
    	
    	from.setFromEmail("f@m");
    	from.setFromName("frommail");

    	Subject subject=context.getBean(Subject.class);
    	
    	subject.setCaption("caption");
    	
    	Body body=context.getBean(Body.class);
    	
    	body.setMessage("i am messsage");
    	
    	
//    	email.setTo(to);
//    	email.setFrom(from);
//    	email.setBody(body);
//    	email.setSubject(subject);
    	
    	
    	
    	//autowiring 
    	//put @autowired in contactdetails property
    	
    	
    	System.out.println(email);
    	
    	
  
    }
}
