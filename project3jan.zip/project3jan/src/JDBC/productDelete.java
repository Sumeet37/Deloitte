package JDBC;

import java.sql.*;
import java.util.*;

public class productDelete {

	public static void main(String[] args) throws SQLException {
		
		Product product=new Product();
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter id to be deleted");
		
		int id=sc.nextInt();
		
		Connection connection=DBConnection.makeConnection();
		String query="delete from hr.product where PRODUCT_ID=?";
		
		PreparedStatement statement=connection.prepareStatement(query);
		
		statement.setInt(1,id);
		
		int rows=statement.executeUpdate();
		
		System.out.println("record deleted sucessfully!!"+rows+" deleted");
		
	
	
	}
}
