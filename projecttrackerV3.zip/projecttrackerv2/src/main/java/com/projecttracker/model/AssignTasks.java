package com.projecttracker.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(schema = "hr" ,name = "TASKS420")
public class AssignTasks {
      
	  @Id
	  private int taskId;
	  @Column
	  private int usertaskId;
	  @Column
	  private String tasks;
      
      public AssignTasks()
      {
    	  
      }

	public int getUsertaskId() {
		return usertaskId;
	}

	public void setUsertaskId(int usertaskId) {
		this.usertaskId = usertaskId;
	}

	public int getTaskId() {
		return taskId;
	}

	public void setTaskId(int taskId) {
		this.taskId = taskId;
	}

	public String getTasks() {
		return tasks;
	}

	public void setTasks(String tasks) {
		this.tasks = tasks;
	}

	@Override
	public String toString() {
		return "AssignTasks [usertaskId=" + usertaskId + ", taskId=" + taskId + ", tasks=" + tasks + "]";
	}
    

	
	
      
}
