package JDBC;

import java.util.Scanner;

public class Product {
	
	private int productId;
	private String productName;
	private int price;
	private int qoh;
	
	public Product() {
		// TODO Auto-generated constructor stub
	}
	public Product(int productId, String productName, int qoh, int price) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.price = price;
		this.qoh = qoh;
	}

	public void accept() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter product id : "); productId = scanner.nextInt();
        System.out.println("Enter product name : "); productName = scanner.next();
        System.out.println("Enter price: "); price = scanner.nextInt();
        System.out.println("Enter QOH : "); qoh = scanner.nextInt();
    }
	
	public void updateProduct() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter existing product id : "); productId = scanner.nextInt();
        System.out.println("Enter new product name : "); productName = scanner.next();
        System.out.println("Enter new price: "); price = scanner.nextInt();
        System.out.println("Enter new QOH : "); qoh = scanner.nextInt();
    }
	
	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getQoh() {
		return qoh;
	}

	public void setQoh(int qoh) {
		this.qoh = qoh;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", qoh=" + qoh + ", price=" + price
				+ "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + price;
		result = prime * result + productId;
		result = prime * result + ((productName == null) ? 0 : productName.hashCode());
		result = prime * result + qoh;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		if (price != other.price)
			return false;
		if (productId != other.productId)
			return false;
		if (productName == null) {
			if (other.productName != null)
				return false;
		} else if (!productName.equals(other.productName))
			return false;
		if (qoh != other.qoh)
			return false;
		return true;
	}
	
	
}



