package com;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.config.AppConfig;

public class AppSpring 
{
    public static void main( String[] args )
    {
        
//    	Resource resource=new ClassPathResource("beans.xml");
    	AbstractApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
    	Customer customer=context.getBean(Customer.class);
    	
    	customer.setCustomerId(1990);
    	customer.setCustomerName("sumeet");
    	customer.setCustomerAddress("LA");
    	customer.setBillAmount(1209);
    	
    	ContactDetails contactDetails=context.getBean(ContactDetails.class);
    	
    	contactDetails.setEmailId("a@b");
    	contactDetails.setMobileNumber(12434);
    	
    	
    	//manual wiring
    	customer.setContactDetails(contactDetails);
    	
    	//autowiring 
    	//put @autowired in contactdetails property
    	
    	
    	
    	
    	System.out.println(customer);
    	
    	
    	Customer customer2=context.getBean(Customer.class);

    	
    	System.out.println(customer2);
    	
    	context.registerShutdownHook();
  
    }
}
