    package com;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Client {

	public static void main(String args[]) {

		Configuration cfg = new Configuration().configure();
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();		
		Transaction tx = session.beginTransaction();

		Employee employee=new Employee(1222,"kalpana");
		session.save(employee);
		
		RegularEmployee regular=new RegularEmployee(41000,9000);
		regular.setEmployeeId(111);
		regular.setEmployeeName("sumeet");
		
		ContractEmployee contract=new ContractEmployee(20,500);
		contract.setEmployeeId(112);
		contract.setEmployeeName("bibhu");
		
		
		
		
		session.save(employee);
		session.save(regular);
		session.save(contract);

		tx.commit();
		session.close();
		System.out.println("done");
		factory.close();

	}
}
