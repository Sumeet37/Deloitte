
// A Dynamic Programming based Java
// implementation to count decodings
import java.io.*;

class Demo {

	int id;
	String name;
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Demo other = (Demo) obj;
		if (id != other.id)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}


	// A Dynamic Programming based
	// function to count decodings
	static int countDecodingDP(char digits[], int n) {
		// A table to store results of subproblems
		int count[] = new int[n + 1];
		count[0] = 1;
		count[1] = 1;
		if (digits[0] == '0') // for base condition "01123" should return 0
			return 0;
		for (int i = 2; i <= n; i++) {
			count[i] = 0;

			// If the last digit is not 0,
			// then last digit must add to
			// the number of words
			if (digits[i - 1] > '0')
				count[i] = count[i - 1];

			// If second last digit is smaller
			// than 2 and last digit is smaller
			// than 7, then last two digits
			// form a valid character
			if (digits[i - 2] == '1' || (digits[i - 2] == '2' && digits[i - 1] < '7'))
				count[i] += count[i - 2];
		}
		return count[n];
	}

	
//	private static int recur(char[] digits, int start, int end) {
//
//		System.out.println("recur " +" "+ start + " "+ end);
//		if(start>=end){
//			return 1;
//		}
//		
//		int count1=recur(digits,start,end-1);
//		
//		
//		int count2=0;
//		
//		
//		int f=(digits[end-1]-'0')*10;
//		int l=(digits[end]-'0');
//		if( f!=0 && f+l<27  ){
//			count2=recur(digits,start,end-2);
//		}
//		
//		return count1+count2;
//		
//	}
	
	// Driver Code
	public static void main(String[] args) {
		String st = "2101";
		char digits[] = st.toCharArray();// {'1','2','3','4'};
		int n = digits.length;
//		System.out.println("Count is " + countDecodingDP(digits, n));
		
//		System.out.println(recur(digits,0,n-1));
	}


	
}

// This code is contributed by anuj_67
// Modified by Atanu Sen
