//// 5 upvote // MESHO q-3
//import java.util.*;
//
//
//class pair{
//	int ind;
//	int cur;
//	pair(int i,int c){
//		ind=i;
//		cur=c;
//	}
//}
//
//public class Test4 {
//
//	
//
//	static HashSet<String> count_unique(String s, int index, int curr, int dest, int n,
//			HashMap<pair, HashSet<String>> d) {
//
//		pair p = new pair(index, curr);
//
//		// if (index, curr) in d:
//		// return d[(index, curr)]
//		if (d.containsKey(p)) {
//			return d.get(p);
//		}
//
//		// result = set([])
//		HashSet<String> result = new HashSet<String>();
//		int next_loc;
//		if (index == s.length())
//			return result;
//
//		result.addAll(count_unique(s, index + 1, curr, dest, n, d));
//
//		if (s.charAt(index) == 'l') {
//			if (curr > 0) {
//				next_loc = curr - 1;
//				if (next_loc == dest)
//					result.add("l");
//				for (String r : count_unique(s, index + 1, next_loc, dest, n, d))
//					result.add('l' + r);
//			}
//		} else {
//			if (curr + 1 < n) {
//				next_loc = curr + 1;
//				if (next_loc == dest)
//					result.add("r");
//				for (String r : (count_unique(s, index + 1, next_loc, dest, n, d)))
//					result.add('r' + r);
//			}
//		}
//		// d[(index, curr)] = result;
//		d.put(p, result);
//		return result;
//
//	}
//
//	static int count_unique_subsequence(String s, int start, int dest, int n) {
//
//		HashSet<String> s1 = count_unique(s, 0, start, dest, n, new HashMap<>());
//		return s1.size();
//
//	}
//
//	struct Point
//	{
//		int x;
//		int y;
//	};
//
//	struct queueNode
//	{
//		Point pt; 
//		int dist; 
//	};
//
//	bool isValid(int row, int col, int n, int n2)
//	{
//		
//		return (row >= 0) && (row < n) &&
//			(col >= 0) && (col < n2);
//	}
//
//
//	int rowNum[] = {-1, 0, 0, 1};
//	int colNum[] = {0, -1, 1, 0};
//
//	int BFS(vector<string> &mat, Point src, Point dest, int n, int n2)
//	{
//
//	   
//		bool visited[n][n2];
//		memset(visited, false, sizeof visited);
//		
//		visited[src.x][src.y] = true;
//
//		queue<queueNode> q;
//		
//		queueNode s = {src, 0};
//		q.push(s);
//
//
//		while (!q.empty())
//		{
//			queueNode curr = q.front();
//			Point pt = curr.pt;
//
//
//			if (pt.x == dest.x && pt.y == dest.y)
//				return curr.dist;
//
//			q.pop();
//
//			for (int i = 0; i < 4; i++)
//			{
//				int row = pt.x + rowNum[i];
//				int col = pt.y + colNum[i];
//				
//
//				if (isValid(row, col, n, n2) && mat[row][col]=='.' &&
//				!visited[row][col])
//				{
//		
//					visited[row][col] = true;
//					queueNode Adjcell = { {row, col},
//										curr.dist + 1 };
//					q.push(Adjcell);
//				}
//			}
//		}
//
//
//		return -1;
//	}
//
//	int main()
//	{
//	    int n, maxTime;
//	    cin >> n;
//		vector<string> mat(n);
//	    for(int i=0;i<n;i++){
//	        cin >> mat[i];
//	    }
//	    cin >> maxTime;
//	    int n2 = mat[0].size();
//		Point source = {0, 0};
//		Point dest = {n-1, n2-1};
//
//		int dist = BFS(mat, source, dest, n, n2);
//		if(dist<=maxTime && dist!=-1){
//	        cout<<"Yes";
//	    }else{
//	        cout<<"No";
//	    }
//
//		return 0;
//	}
//	
//	
//	public static void main(String[] args) {
//		
//		
//	}
//
//}
