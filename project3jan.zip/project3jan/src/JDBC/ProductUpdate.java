package JDBC;
import java.sql.*;
import java.util.*;

public class ProductUpdate {
	
	public static void main(String[] args) throws SQLException {
		Product product=new Product();
		product.updateProduct();
		
		Connection connection=DBConnection.makeConnection();
		String query="update hr.temp_product set PRODUCTNAME=?,PRICE=?,QOH=?where PRODUCT_ID=?";
		
		PreparedStatement statement=connection.prepareStatement(query);
		
		statement.setString(1,product.getProductName());
		statement.setInt(2,product.getPrice());
		statement.setInt(3,product.getQoh());
		statement.setInt(4,product.getProductId());
		
		statement.executeUpdate();
		
		System.out.println(product.getProductName()+" ,  record updated sucessfully!!");
		
		
	
		
	}
	
	
	
	

}
