package Tree;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.*;
import java.util.Queue;
import java.util.logging.Level;

class Node{
	int data;
	Node left;
	Node right;
	
	Node(int data){
		this.data=data;
		this.left=this.right=null;
		
	}
}

public class CustomTree {

	Node root1;
	Node root2;
	
	int maxDepth(Node root){
		
		if(root==null){
			return 0;
		}
		
		int left=maxDepth(root.left);
		int right=maxDepth(root.right);
		
		return Math.max(left, right)+1;
		
	}
	
	boolean identicalTrees(Node root1, Node root2){
		
		if(root1==null && root2==null){
			return true;
		}else if(root1==null || root2==null){
			return false;
		}
		
		if(root1.data!=root2.data){
			return false;
		}
		
		boolean isLeftTreeIdentical=identicalTrees(root1.left,root2.left);
		boolean isRightTreeIdentical=identicalTrees(root1.right,root2.right);
		
		return isLeftTreeIdentical && isRightTreeIdentical;
		
	}

	public Node invertTree(Node root) {

		if (root == null)
			return null;

		Node l = invertTree(root.left);
		Node r = invertTree(root.right);

		root.left = r;
		root.right = l;

		return root;
	}

	 public  List<List<Integer>> levelOrder(Node root) {
	        Queue<Node> q=new ArrayDeque();
	        q.add(root);
	        List<List<Integer>> output=new ArrayList<>();
	        List<Integer> levelOutput;
	        int qlen;
	        while(!q.isEmpty()){
	            
	        	qlen=q.size();
	            levelOutput=new ArrayList<>();
	            for(int i=0;i<qlen;i++){
	            	Node pollNode=q.poll();
	            	levelOutput.add(pollNode.data);
	            	
	            	if(pollNode.left!=null){
	            		q.add(pollNode.left);
	            	}
	            	if(pollNode.right!=null){
	            		q.add(pollNode.right);
	            	}
	            }
	            output.add(levelOutput);
	            
	        }
	        return output;
	        
	    }
	 
	 //Subtree of Another Tree
	 
	 
	 
	
	public static void main(String[] args) {

		CustomTree tree = new CustomTree();
		  
	        tree.root1 = new Node(1);
	        tree.root1.left = new Node(2);
	        tree.root1.right = new Node(3);
	        tree.root1.left.left = new Node(4);
	        tree.root1.left.right = new Node(5);
	  
	        tree.root2 = new Node(1);
	        tree.root2.left = new Node(2);
	        tree.root2.right = new Node(3);
	        tree.root2.left.left = new Node(4);
	        tree.root2.left.right = new Node(5);
	        
	        
	        
	        //identical tree
	        
	        System.out.println("Identicality of trees");
	        System.out.println(tree.identicalTrees(tree.root1, tree.root2));
	        
	        System.out.println("level order");
	        System.out.println(tree.levelOrder(tree.root1));
	        // 
	        
	        
		
		
	}

}
