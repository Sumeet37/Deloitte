package oops;

public class Client {
public static void main(String[] args) {
	Employee e=new Employee();
	e.takeSalary();
	e.print();
}
}
