package com.projecttracker.task.controller;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.projecttracker.model.AssignTasks;
import com.projecttracker.model.User;
import com.projecttracker.task.service.impl.AssignTasksServiceImpl;

@Controller
public class ProjectController {
        
	User leader;
	User retreiveduser;
	
	@Autowired
	AssignTasksServiceImpl tasksimpl;
	
	@RequestMapping("login")
	public ModelAndView viewloginpage()
	{
		ModelAndView view=new ModelAndView();
		view.addObject("command",new User());
		view.setViewName("login");
		return view;
	}
	
	@RequestMapping("loginauthentication")
	public ModelAndView loginpage(User user)
	{
		ModelAndView view=new ModelAndView();
		
		System.out.println(user);
		boolean ifExist=tasksimpl.authenticate(user);
		
		if(!ifExist) {
			view.setViewName("error");	
		}
		else {
			//check lead or user
			boolean Leader_Status= tasksimpl.checkLeaderStatus(user);
			if(Leader_Status) {
				//lead
				
				leader=tasksimpl.userInfoById(user.getUserId());
				System.out.println(leader);
				
				view.setViewName("redirect:/leader");
				}
			else {
				//user
				retreiveduser=tasksimpl.userInfoById(user.getUserId());
				view.setViewName("redirect:/user");
			}
		}
		
		view.addObject("command",new User());
		return view;
	}
	

	
	
	@RequestMapping("leader")
	public ModelAndView viewTask()
	{
		
		ModelAndView view=new ModelAndView("leader");
		view.addObject("leader",leader);
		view.addObject("task",new AssignTasks());
		return view;
	}
	
	
	
	@RequestMapping("viewleader")
	public ModelAndView addTask(AssignTasks tasks)
	{	
		
		tasksimpl.addTasks(tasks);
		
		
		ModelAndView view=new ModelAndView("redirect:/leader");
		view.addObject("task", new AssignTasks());
		return view;
	}
	
	
	
	
	@RequestMapping("user")
	public ModelAndView viewUser()
	{
		
//		tasksimpl.addTasks(tasks);
		
		List<AssignTasks> task=tasksimpl.listTasks(retreiveduser.getUserId());
		
		
		ModelAndView view=new ModelAndView("user");
		
		view.addObject("user",retreiveduser);
		view.addObject("tAssigned",task);
		return view;
	}
	
	
	@RequestMapping("/deleteTask/{taskId}")
	public ModelAndView deleteTask(@PathVariable("taskId") Integer taskId)
	{   
		ModelAndView view=new ModelAndView("redirect:/user");
		tasksimpl.completedTasks(taskId);
		return view;
	}

	

}
