package uncheckedExceptionPackage;
import java.util.*;

class InvalidAgeException1 extends RuntimeException{
	public InvalidAgeException1() {
	
	}
	
	public InvalidAgeException1(String msg) {
		super(msg);

	}
		
}

class NewYearParty1 {

	int eligibleAge=16;
	Scanner scanner=new Scanner(System.in);
	int age;
	public void enterClub(){
		System.out.println("enter your age");
		age=scanner.nextInt();
		
		if(age<eligibleAge) {
			throw new InvalidAgeException1("under age");
			
		}else {
			System.out.println("welcome");
		}
	}
	
}

public class NewYearPartyUserDefinedUncheckedException
{
	public static void main(String[] args) {
		NewYearParty1 obj=new NewYearParty1();
		
		obj.enterClub();
		
			
	
		
		
	}
	
	
}
