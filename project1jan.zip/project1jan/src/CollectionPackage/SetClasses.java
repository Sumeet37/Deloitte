package CollectionPackage;

import java.util.*;
public class SetClasses {

	public static void main(String[] args) {
		
	Set<String> names=new LinkedHashSet<>();
	names.add("jay");
	names.add("veeru");
	names.add("neha");
	names.add("spring");
	
	System.out.println(names);
	Iterator <String> i=names.iterator();
	
	while(i.hasNext()) {
		String str=i.next();
		if(str.equals("neha")) {
			continue;
		}
		System.out.println(str);
		
	}
	
	
	
	
	}
}
