package iodemos;

public class FileOutputStreamDemo {

}
