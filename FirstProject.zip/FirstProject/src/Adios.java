
public class Adios {
public void sayAdios() {
	System.out.println("chao adios");
}
}
